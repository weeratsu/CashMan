// ui-bills.js — Recurring, Installments, Planned

function swBills(el,tab){document.querySelectorAll('#tab-bills .sub-panel').forEach(function(p){p.classList.remove('active')});document.querySelectorAll('#tab-bills .sub-tab').forEach(function(t){t.classList.remove('active')});el.classList.add('active');document.getElementById('bp-'+tab).classList.add('active');
if(tab==='installments'){try{renderInstMatrix()}catch(e){}}}

function renderMonthly(){
document.getElementById('monthly-hdr').innerHTML='<th style="width:24px"><input type="checkbox" onchange="toggleAllMonthly(this.checked)"></th>'+sHdr('monthly','name','Name')+'<th>I/E</th>'+sHdr('monthly','type','Type')+sHdr('monthly','amount','Amount')+sHdr('monthly','billing_day','Bill Day')+'<th>Pay By</th><th class="r">Eff.</th><th>Ends</th><th>Status</th><th></th>';
document.getElementById('monthly-body').innerHTML=D.monthly.map(function(m,i){var ep2=effPayment(m),ed=ep2.day,sh=m.card!=='Cash/Direct'&&(ed!==m.billing_day||ep2.monthShift>0),ms=ep2.monthShift;
var dirCls=m.direction==='income'?'color:var(--success);font-weight:600':'';
var st=m.status||'Active';var stStyle=st==='Hold'?'color:var(--warning)':st==='Cancelled'?'color:var(--error);text-decoration:line-through':'color:var(--success)';
var rowOpac=st!=='Active'?'opacity:.5;':'';
var em=m.end_mode||'forever';var endHtml='<select class="sel" style="font-size:9px;width:75px" data-mi="'+i+'" data-f="end_mode" onchange="var dr=this.closest(\'tr\').querySelector(\'.m-enddt\');if(dr)dr.style.display=this.value===\'date\'?\'\':\'none\'"><option value="forever"'+(em==='forever'?' selected':'')+'>∞ Forever</option><option value="date"'+(em==='date'?' selected':'')+'>📅 Until</option></select>';
endHtml+='<input type="date" class="inp m-enddt" value="'+(em==='date'?(m.end_date||''):'')+'" style="width:110px;padding:1px 3px;font-size:9px;margin-top:2px;display:'+(em==='date'?'':'none')+'" data-mi="'+i+'" data-f="end_date">';
return '<tr style="'+(m.direction==='income'?'background:rgba(16,185,129,0.05)':'')+rowOpac+'"><td><input type="checkbox" class="m-chk" data-idx="'+i+'" onchange="updateMonthlyBulk()"></td><td><input class="inp-inline" value="'+esc(m.name)+'" data-mi="'+i+'" data-f="name"></td>'+
'<td><select class="sel" style="'+dirCls+'" data-mi="'+i+'" data-f="direction">'+dirOpts(m.direction)+'</select></td>'+
'<td><select class="sel" data-mi="'+i+'" data-f="type">'+tOpts(m.type)+'</select></td>'+
'<td class="r"><input class="inp inp-num" type="text" value="'+fmt(m.amount)+'" style="width:75px;padding:2px 4px;font-size:10px" data-mi="'+i+'" data-f="amount" onfocus="var v=parseFloat(this.value.replace(/,/g,\'\'));this.value=v||\'\';" onblur="this.value=(parseFloat(this.value.replace(/,/g,\'\'))||0).toLocaleString(\'en-US\',{minimumFractionDigits:2,maximumFractionDigits:2})"></td>'+
'<td class="r"><input type="number" class="inp inp-num" value="'+m.billing_day+'" min="1" max="31" style="width:35px;padding:2px 4px;font-size:10px" data-mi="'+i+'" data-f="billing_day"></td>'+
'<td><select class="sel" data-mi="'+i+'" data-f="card">'+cOpts(m.card)+'</select></td>'+
'<td class="r">'+(sh?'<span class="shifted">'+ord(ed)+(ms>0?' +1mo':'')+'</span>':'<span class="orig">'+ord(ed)+'</span>')+'</td>'+
'<td>'+endHtml+'</td>'+
'<td><select class="sel" style="font-size:9px;'+stStyle+'" data-mi="'+i+'" data-f="status"><option value="Active"'+(st==='Active'?' selected':'')+' style="color:var(--success)">Active</option><option value="Hold"'+(st==='Hold'?' selected':'')+' style="color:var(--warning)">Hold</option><option value="Cancelled"'+(st==='Cancelled'?' selected':'')+' style="color:var(--error)">Cancelled</option></select></td>'+
'<td><button class="del-btn" onclick="readAll();D.monthly.splice('+i+',1);renderMonthly()"><i class="fa-solid fa-trash"></i></button></td></tr>'}).join('')}

function addMonthly(){readAll();D.monthly.push({name:'New',type:D.types[0]||'Other',amount:0,billing_day:1,card:'Cash/Direct',direction:'expense',status:'Active',end_mode:'forever',end_date:''});renderMonthly();filterMonthly()}

function toggleAllMonthly(c){document.querySelectorAll('.m-chk').forEach(function(cb){var tr=cb.closest('tr');if(tr&&tr.style.display!=='none')cb.checked=c});updateMonthlyBulk()}
function updateMonthlyBulk(){var n=document.querySelectorAll('.m-chk:checked').length;var el=document.getElementById('monthly-bulk');if(el)el.style.display=n>0?'':'none';var c=document.getElementById('m-sel-count');if(c)c.textContent=n}
function deleteSelectedMonthly(){var idxs=[];document.querySelectorAll('.m-chk:checked').forEach(function(cb){idxs.push(parseInt(cb.dataset.idx))});if(!idxs.length)return;if(!confirm('Delete '+idxs.length+' monthly item(s)?'))return;readAll();idxs.sort(function(a,b){return b-a});idxs.forEach(function(i){D.monthly.splice(i,1)});saveD();renderMonthly();filterMonthly();toast('\ud83d\uddd1\ufe0f Deleted '+idxs.length+' item(s)')}

// YEARLY

function renderYearly(){
document.getElementById('yearly-hdr').innerHTML='<th style="width:24px"><input type="checkbox" onchange="toggleAllYearly(this.checked)"></th>'+sHdr('yearly','name','Name')+sHdr('yearly','direction','I/E')+sHdr('yearly','type','Type')+sHdr('yearly','amount','Amount')+sHdr('yearly','billing_day','Day')+sHdr('yearly','month','Month')+sHdr('yearly','pay_mode','Pay Mode')+sHdr('yearly','card','Card')+sHdr('yearly','inst_periods','Periods')+'<th>Status</th><th></th>';
document.getElementById('yearly-body').innerHTML=D.yearly.map(function(y,i){
var yDirCls=y.direction==='income'?'color:var(--success);font-weight:600':'';
var yst=y.status||'Active';var ystStyle=yst==='Hold'?'color:var(--warning)':yst==='Cancelled'?'color:var(--error);text-decoration:line-through':'color:var(--success)';
var yRowOpac=yst!=='Active'?'opacity:.5;':'';
return '<tr style="'+(y.direction==='income'?'background:rgba(16,185,129,0.05)':'')+yRowOpac+'"><td><input type="checkbox" class="y-chk" data-idx="'+i+'" onchange="updateYearlyBulk()"></td><td><input class="inp-inline" value="'+esc(y.name)+'" data-yi="'+i+'" data-f="name"></td>'+
'<td><select class="sel" style="'+yDirCls+'" data-yi="'+i+'" data-f="direction">'+dirOpts(y.direction)+'</select></td>'+
'<td><select class="sel" data-yi="'+i+'" data-f="type">'+tOpts(y.type)+'</select></td>'+
'<td class="r"><input class="inp inp-num" type="text" value="'+fmt(y.amount)+'" style="width:75px;padding:2px 4px;font-size:10px" data-yi="'+i+'" data-f="amount" onfocus="var v=parseFloat(this.value.replace(/,/g,\'\'));this.value=v||\'\';" onblur="this.value=(parseFloat(this.value.replace(/,/g,\'\'))||0).toLocaleString(\'en-US\',{minimumFractionDigits:2,maximumFractionDigits:2})"></td>'+
'<td style="white-space:nowrap"><input type="number" class="inp inp-num" value="'+y.billing_day+'" min="1" max="31" style="width:32px;padding:2px 3px;font-size:10px" data-yi="'+i+'" data-f="billing_day"></td>'+
'<td><select class="sel" style="width:48px;font-size:10px" data-yi="'+i+'" data-f="month">'+MO.map(function(mn,mi){return '<option value="'+(mi+1)+'"'+(y.month===mi+1?' selected':'')+'>'+mn+'</option>'}).join('')+'</select></td>'+
'<td><select class="sel" data-yi="'+i+'" data-f="pay_mode" onchange="readAll();if(this.value===\'full\')D.yearly['+i+'].inst_periods=1;saveD();renderYearly();filterYearly()"><option value="full"'+(y.pay_mode==='full'?' selected':'')+'>Full</option><option value="installment"'+(y.pay_mode==='installment'?' selected':'')+'>Installment</option></select></td>'+
'<td><select class="sel" data-yi="'+i+'" data-f="card">'+cOpts(y.card)+'</select></td>'+
'<td class="r">'+(y.pay_mode==='installment'?'<input type="number" class="inp inp-num" value="'+y.inst_periods+'" min="1" max="60" style="width:35px;padding:2px 4px;font-size:10px" data-yi="'+i+'" data-f="inst_periods">':'<input type="number" class="inp inp-num" value="1" min="1" max="1" disabled style="width:35px;padding:2px 4px;font-size:10px;opacity:.5" data-yi="'+i+'" data-f="inst_periods">')+'</td>'+
'<td><select class="sel" style="font-size:9px;'+ystStyle+'" data-yi="'+i+'" data-f="status"><option value="Active"'+(yst==='Active'?' selected':'')+' style="color:var(--success)">Active</option><option value="Hold"'+(yst==='Hold'?' selected':'')+' style="color:var(--warning)">Hold</option><option value="Cancelled"'+(yst==='Cancelled'?' selected':'')+' style="color:var(--error)">Cancelled</option></select></td>'+
'<td><button class="del-btn" onclick="readAll();D.yearly.splice('+i+',1);renderYearly()"><i class="fa-solid fa-trash"></i></button></td></tr>'}).join('')}

function addYearly(){readAll();D.yearly.push({name:'New',type:D.types[0]||'Other',amount:0,billing_day:1,month:1,card:'Cash/Direct',pay_mode:'full',inst_periods:1,own_by:'Me',status:'Active'});renderYearly();filterYearly()}

function toggleAllYearly(c){document.querySelectorAll('.y-chk').forEach(function(cb){var tr=cb.closest('tr');if(tr&&tr.style.display!=='none')cb.checked=c});updateYearlyBulk()}
function updateYearlyBulk(){var n=document.querySelectorAll('.y-chk:checked').length;var el=document.getElementById('yearly-bulk');if(el)el.style.display=n>0?'':'none';var c=document.getElementById('y-sel-count');if(c)c.textContent=n}
function deleteSelectedYearly(){var idxs=[];document.querySelectorAll('.y-chk:checked').forEach(function(cb){idxs.push(parseInt(cb.dataset.idx))});if(!idxs.length)return;if(!confirm('Delete '+idxs.length+' yearly item(s)?'))return;readAll();idxs.sort(function(a,b){return b-a});idxs.forEach(function(i){D.yearly.splice(i,1)});saveD();renderYearly();filterYearly();toast('\ud83d\uddd1\ufe0f Deleted '+idxs.length+' item(s)')}

// INSTALLMENTS


function togInstMonth(el){el.nextElementSibling.classList.toggle('open');el.querySelector('.arr').classList.toggle('open')}

function renderInstMonthly(){
var all=allInstallments().filter(function(x){return x.status==='Active'||x.status==='Planned'});
if(!all.length){
document.getElementById('inst-monthly-kpis').innerHTML='<div class="kpi"><div class="kpi-label">No active installments</div></div>';
document.getElementById('inst-monthly-table').innerHTML='';return}
var sd=new Date(D.profile.start_date+'T00:00:00'),ed=new Date(D.profile.end_date+'T00:00:00');
var months={},monthKeys=[];
var cur=new Date(sd.getFullYear(),sd.getMonth(),1);
while(cur<=ed){var mk=cur.getFullYear()+'-'+(cur.getMonth()+1<10?'0':'')+(cur.getMonth()+1);
months[mk]={label:MO[cur.getMonth()]+' '+cur.getFullYear(),items:[],total:0};
monthKeys.push(mk);cur.setMonth(cur.getMonth()+1)}
all.forEach(function(inst){
var sy=inst.start_year||parseInt(D.profile.start_date.slice(0,4)),sm=inst.start_month||1;
for(var p=0;p<inst.periods;p++){
var m=sm+p-1,y=sy+Math.floor(m/12);m=m%12+1;
var mk=y+'-'+(m<10?'0':'')+m;
if(months[mk]){months[mk].items.push({name:inst.name,amount:inst.per_period,card:inst.card,info:'('+(p+1)+'/'+inst.periods+')'});
months[mk].total+=inst.per_period}}});
var now=new Date();var nowMk=now.getFullYear()+'-'+(now.getMonth()+1<10?'0':'')+(now.getMonth()+1);
var thisMonth=months[nowMk]||{total:0,items:[]};
var nextMk=now.getFullYear()+'-'+(now.getMonth()+2<10?'0':'')+(now.getMonth()+2);
if(now.getMonth()===11)nextMk=(now.getFullYear()+1)+'-01';
var nextMonth=months[nextMk]||{total:0,items:[]};
var peakMonth={label:'-',total:0};var activeMonths=0;
monthKeys.forEach(function(mk){var m=months[mk];if(m.total>0){activeMonths++;if(m.total>peakMonth.total)peakMonth={label:m.label,total:m.total}}});
var payNet=computePayroll(1).net;
document.getElementById('inst-monthly-kpis').innerHTML=
'<div class="kpi"><div class="kpi-label">This Month</div><div class="kpi-val text-error">\u0e3f'+fmt(thisMonth.total)+'</div><div class="kpi-note">'+thisMonth.items.length+' items'+(payNet>0?' \u2022 '+(thisMonth.total/payNet*100).toFixed(1)+'% of pay':'')+'</div></div>'+
'<div class="kpi"><div class="kpi-label">Next Month</div><div class="kpi-val text-warning">\u0e3f'+fmt(nextMonth.total)+'</div><div class="kpi-note">'+nextMonth.items.length+' items</div></div>'+
'<div class="kpi"><div class="kpi-label">Peak Month</div><div class="kpi-val text-primary">\u0e3f'+fmt(peakMonth.total)+'</div><div class="kpi-note">'+esc(peakMonth.label)+'</div></div>'+
'<div class="kpi"><div class="kpi-label">Active Months</div><div class="kpi-val">'+activeMonths+'</div><div class="kpi-note">with payments</div></div>';
var h='<table class="tbl" style="margin-top:8px"><thead><tr><th style="width:28px"></th><th>Month</th><th class="r">Items</th><th class="r">Total</th><th class="r">% of Pay</th></tr></thead><tbody>';
monthKeys.forEach(function(mk){var m=months[mk];if(m.total===0)return;
var isNow=mk===nowMk;
var rowStyle=isNow?'background:var(--primary-bg);font-weight:600':'';
h+='<tr style="cursor:pointer;'+rowStyle+'" onclick="togInstMonth(this)">';
h+='<td><span class="arr" style="font-size:8px;color:var(--text3)">\u25b6</span></td>';
h+='<td style="font-size:11px">'+(isNow?'\u{1f4cd} ':'')+esc(m.label)+'</td>';
h+='<td class="r" style="font-size:10px;color:var(--text3)">'+m.items.length+'</td>';
h+='<td class="r" style="font-family:var(--mono);font-size:11px;font-weight:600;color:var(--error)">\u0e3f'+fmt(m.total)+'</td>';
h+='<td class="r" style="font-family:var(--mono);font-size:10px;color:var(--text3)">'+(payNet>0?(m.total/payNet*100).toFixed(1)+'%':'-')+'</td></tr>';
h+='<tr class="acc-body"><td colspan="5" style="padding:0">';
h+='<div style="padding:4px 8px 4px 32px;background:var(--bg3)">';
m.items.forEach(function(it){
h+='<div style="display:flex;gap:6px;padding:2px 0;font-size:10px">';
h+='<span style="flex:1">'+esc(it.name)+'</span>';
if(it.card)h+='<span class="day-card">'+esc(it.card)+'</span>';
h+='<span style="font-size:8px;padding:0 4px;border-radius:4px;background:var(--bg3);color:var(--text3);font-family:var(--mono)">'+esc(it.info)+'</span>';
h+='<span style="font-family:var(--mono);min-width:70px;text-align:right">\u0e3f'+fmt(it.amount)+'</span>';
h+='</div>'});
h+='</div></td></tr>'});
h+='</tbody></table>';
document.getElementById('inst-monthly-table').innerHTML=h}


function renderInst(){var all=allInstallments();
all.forEach(function(x,i){x._oi=i});
if(instSortState.col){var sc=instSortState.col,sa=instSortState.asc;
all.sort(function(a,b){var va,vb;
if(sc==='start_month'){va=(a.start_year||0)*10000+(a.start_month||0)*100+(a.start_day||0);vb=(b.start_year||0)*10000+(b.start_month||0)*100+(b.start_day||0);return sa?va-vb:vb-va}
va=a[sc];vb=b[sc];
if(typeof va==='number'&&typeof vb==='number')return sa?va-vb:vb-va;
va=String(va||'').toLowerCase();vb=String(vb||'').toLowerCase();
return sa?va.localeCompare(vb):vb.localeCompare(va)})}
var normalPay2=computePayroll(1);var annualIncome2=normalPay2.net*12+(computePayroll(12).net-normalPay2.net);
var activeInst=all.filter(function(x){return x.status==='Active'||x.status==='Planned'});
var instMonthly=activeInst.reduce(function(s,x){return s+x.per_period},0);
var instTotal=activeInst.reduce(function(s,x){return s+x.total},0);
document.getElementById('inst-kpis').innerHTML=
'<div class="kpi"><div class="kpi-label">Active Items</div><div class="kpi-val">'+activeInst.length+'</div></div>'+
'<div class="kpi"><div class="kpi-label">Peak Monthly</div><div class="kpi-val text-error">\u0e3f'+fmt(instMonthly)+'</div><div class="kpi-note">'+(normalPay2.net>0?(instMonthly/normalPay2.net*100).toFixed(1)+'% of net pay':'')+'</div></div>'+
'<div class="kpi"><div class="kpi-label">Total Committed</div><div class="kpi-val">\u0e3f'+fmt(instTotal)+'</div><div class="kpi-note">'+(annualIncome2>0?(instTotal/annualIncome2*100).toFixed(1)+'% of annual income':'')+'</div></div>';
var instByType={};activeInst.forEach(function(x){var t=x.type||'Other';if(!instByType[t])instByType[t]={items:[],total:0};instByType[t].items.push(x);instByType[t].total+=x.total});
var igH='';Object.keys(instByType).sort().forEach(function(t){var g=instByType[t];
igH+='<div class="acc-header" onclick="this.querySelector(\'.arr\').classList.toggle(\'open\');this.nextElementSibling.classList.toggle(\'open\')">'+
'<span class="arr">\u25b6</span><span style="flex:1;font-weight:600;font-size:12px">'+esc(t)+'</span>'+
'<span style="font-size:9px;color:var(--text3);margin-right:8px">'+(annualIncome2>0?(g.total/annualIncome2*100).toFixed(1)+'%':'')+'</span>'+
'<span style="font-family:var(--mono);font-size:11px;font-weight:600;min-width:90px;text-align:right">\u0e3f'+fmt(g.total)+'</span></div>'+
'<div class="acc-body">';
g.items.forEach(function(it){
igH+='<div class="day-row" style="padding-left:32px"><span class="day-name" style="font-size:11px">'+esc(it.name)+'</span>'+
'<span style="font-size:9px;color:var(--text3);margin:0 6px">'+esc(it.card)+'</span>'+
'<span class="day-amt" style="font-size:10px">\u0e3f'+fmt(it.per_period)+'/mo</span>'+
'<span style="font-size:9px;color:var(--text3);min-width:35px;text-align:right;margin-right:4px">'+(annualIncome2>0?(it.total/annualIncome2*100).toFixed(1)+'%':'')+'</span>'+
'<span class="day-bal" style="font-size:10px;min-width:80px">\u0e3f'+fmt(it.total)+'</span></div>'});
igH+='</div>'});
document.getElementById('inst-summary-groups').innerHTML=igH;

// Sortable headers for manual installments
var iHdr='<th style="width:24px"><input type="checkbox" id="inst-select-all" onchange="toggleAllInst(this.checked)"></th>'+iSH('name','Item')+iSH('type','Type')+iSH('card','Card')+iSH('own_by','Own By')+
iSH('total','Total')+iSH('per_period','Per Period')+iSH('periods','Periods')+
iSH('start_month','Start Date')+'<th>Status</th><th>Source</th><th></th>';
document.getElementById('inst-hdr').innerHTML=iHdr;

// Render rows - manual items are editable, auto items are read-only
var rows='';
var manualCount=D.installments.length;
all.forEach(function(inst,i){
var isAuto=inst.source==='Yearly';
var st=inst.status||'Active';
var stTag='<span class="tag tag-'+st.toLowerCase()+'">'+st+'</span>';
var srcTag=isAuto?'<span class="tag tag-auto">Auto</span>':'<span class="tag" style="background:var(--bg3);color:var(--text3)">Manual</span>';
var opac=st==='Finished'||st==='Cancelled'?'opacity:.4;':'';

if(isAuto){
var ai=inst._oi-manualCount;
rows+='<tr data-idx="'+inst._oi+'" style="'+opac+'"><td style="width:24px"><input type="checkbox" class="inst-chk" data-auto="'+ai+'" value="'+inst._oi+'" onchange="updateInstBulkActions()"></td><td>'+esc(inst.name)+'</td><td>'+esc(inst.type)+'</td><td><span class="tag tag-auto" style="font-size:9px">'+esc(inst.card)+'</span></td>'+
'<td>'+esc(inst.own_by)+'</td><td class="r" style="font-family:var(--mono);font-size:10px">\u0e3f'+fmt(inst.total)+'</td>'+
'<td class="r" style="font-family:var(--mono);font-size:10px">\u0e3f'+fmt(inst.per_period)+'</td>'+
'<td class="r" style="font-family:var(--mono)">'+inst.periods+'</td>'+
'<td style="font-size:10px">'+((inst.start_day||1)<10?'0':'')+(inst.start_day||1)+'/'+(inst.start_month<10?'0':'')+inst.start_month+'/'+inst.start_year+'</td>'+
'<td>'+stTag+'</td><td>'+srcTag+'</td>'+
'<td><button class="del-btn" title="Convert to editable" onclick="convertAutoInst('+ai+')" style="font-size:9px;padding:2px 5px">\u270f\ufe0f</button></td></tr>'}
else{
rows+='<tr data-idx="'+inst._oi+'" style="'+opac+'"><td style="width:24px"><input type="checkbox" class="inst-chk" value="'+inst._oi+'" onchange="updateInstBulkActions()"></td><td><input class="inp-inline" value="'+esc(inst.name)+'" data-ii="'+inst._oi+'" data-f="name"></td>'+
'<td><select class="sel" data-ii="'+inst._oi+'" data-f="type">'+tOpts(inst.type)+'</select></td>'+
'<td><select class="sel" data-ii="'+inst._oi+'" data-f="card">'+cOnlyOpts(inst.card)+'</select></td>'+
'<td><select class="sel" data-ii="'+inst._oi+'" data-f="own_by">'+oOpts(inst.own_by)+'</select></td>'+
'<td class="r"><input class="inp inp-num" type="text" value="'+fmt(inst.total)+'" style="width:80px;padding:2px 4px;font-size:10px" data-ii="'+inst._oi+'" data-f="total" onchange="calcPP('+i+')" onfocus="var v=parseFloat(this.value.replace(/,/g,\'\'));this.value=v||\'\';" onblur="this.value=(parseFloat(this.value.replace(/,/g,\'\'))||0).toLocaleString(\'en-US\',{minimumFractionDigits:2,maximumFractionDigits:2})"></td>'+
'<td class="r"><input class="inp inp-num" type="text" value="'+fmt(inst.per_period)+'" style="width:80px;padding:2px 4px;font-size:10px" data-ii="'+inst._oi+'" data-f="per_period" onfocus="var v=parseFloat(this.value.replace(/,/g,\'\'));this.value=v||\'\';" onblur="this.value=(parseFloat(this.value.replace(/,/g,\'\'))||0).toLocaleString(\'en-US\',{minimumFractionDigits:2,maximumFractionDigits:2})"></td>'+
'<td class="r"><input type="number" class="inp inp-num" value="'+inst.periods+'" min="1" max="60" style="width:40px;padding:2px 4px;font-size:10px" data-ii="'+inst._oi+'" data-f="periods" onchange="calcPP('+i+')"></td>'+
'<td><input type="date" class="inp" value="'+inst.start_year+'-'+(inst.start_month<10?'0':'')+inst.start_month+'-'+((inst.start_day||1)<10?'0':'')+(inst.start_day||1)+'" style="width:115px;padding:2px 4px;font-size:10px" data-ii="'+inst._oi+'" data-f="start_date"></td>'+
'<td><select class="sel" data-ii="'+inst._oi+'" data-f="status">'+STATUSES.map(function(s){return '<option'+(st===s?' selected':'')+'>'+s+'</option>'}).join('')+'</select></td>'+
'<td>'+srcTag+'</td>'+
'<td><button class="del-btn" onclick="if(confirm(\'Delete?\')){{readAll();D.installments.splice('+inst._oi+',1);renderInst()}}"><i class="fa-solid fa-trash"></i></button></td></tr>'}});
document.getElementById('inst-body').innerHTML=rows;
populateInstDropdown()}

var instSortState={col:null,asc:true};

function iSH(col,label){
var arrow=instSortState.col===col?(instSortState.asc?' \u25b2':' \u25bc'):'';
var isNum=col==='total'||col==='per_period'||col==='periods'||col==='start_month';
return '<th style="cursor:pointer" onclick="readAll();sortInst(\''+col+'\')" '+(isNum?'class="r"':'')+'>'+label+arrow+'</th>'}


function calcPP(idx){
var inst=D.installments[idx];if(!inst)return;
readAll();
if(inst.total>0&&inst.periods>0){
inst.per_period=Math.round(inst.total/inst.periods*100)/100;
renderInst()}}



function sortInst(col){
if(instSortState.col===col)instSortState.asc=!instSortState.asc;else{instSortState.col=col;instSortState.asc=true}
renderInst();renderInstMonthly();filterInst()}


function toggleAllInst(checked){
document.querySelectorAll('.inst-chk').forEach(function(cb){
var tr=cb.closest('tr');
if(tr&&tr.style.display==='none')return;
cb.checked=checked});
updateInstBulkActions()}


function updateInstBulkActions(){
var count=0;
document.querySelectorAll('.inst-chk:checked').forEach(function(cb){
var tr=cb.closest('tr');
if(tr&&tr.style.display!=='none')count++});
var el=document.getElementById('inst-bulk-actions');
var countEl=document.getElementById('inst-sel-count');
if(el)el.style.display=count>0?'':'none';
if(countEl)countEl.textContent=count}


function deleteSelectedInst(){
var manualIndices=[],autoIndices=[];
document.querySelectorAll('.inst-chk:checked').forEach(function(cb){
var tr=cb.closest('tr');if(tr&&tr.style.display==='none')return;
if(cb.dataset.auto!=null){autoIndices.push(parseInt(cb.dataset.auto))}
else{manualIndices.push(parseInt(cb.value))}});
var total=manualIndices.length+autoIndices.length;
if(total===0)return;
if(!confirm('Delete '+total+' selected installment(s)?'))return;
readAll();
manualIndices.sort(function(a,b){return b-a});
manualIndices.forEach(function(idx){D.installments.splice(idx,1)});
if(autoIndices.length>0){
var autoItems=[];
D.yearly.forEach(function(y,yi){if(y.pay_mode==='installment'){autoItems.push(yi)}});
autoIndices.sort(function(a,b){return b-a});
autoIndices.forEach(function(ai){
if(ai>=0&&ai<autoItems.length){D.yearly[autoItems[ai]].pay_mode='full';D.yearly[autoItems[ai]].inst_periods=1}})}
saveD();simulate();renderAllTabs();
toast('\ud83d\uddd1\ufe0f Deleted '+total+' item(s)')}

var plannedSortState={col:null,asc:true};

function pSH(col,label){var st=plannedSortState;var arrow=st.col===col?(st.asc?' \u25b2':' \u25bc'):'';
var isNum=['amount'].indexOf(col)>=0;
return '<th style="cursor:pointer" onclick="readAll();sortPlanned(\''+col+'\')" '+(isNum?'class="r"':'')+'>'+label+arrow+'</th>'}


function renderInstMatrix(){
var el=document.getElementById('inst-matrix');if(!el)return;
var all=allInstallments().filter(function(x){return x.status==='Active'||x.status==='Planned'});
if(!all.length){el.innerHTML='<div class="text-muted" style="font-size:10px;padding:8px">No active installments.</div>';return}

// Build month range from profile
var sd=new Date(D.profile.start_date+'T00:00:00'),ed=new Date(D.profile.end_date+'T00:00:00');
var months=[],cur=new Date(sd.getFullYear(),sd.getMonth(),1);
while(cur<=ed){months.push({y:cur.getFullYear(),m:cur.getMonth()});cur.setMonth(cur.getMonth()+1)}

// Build matrix: for each installment, determine which months have payments
var matrix={};// key: instIdx, value: {monthKey: amount}
var instNames=[];
all.forEach(function(inst,idx){
instNames.push({name:inst.name,card:inst.card||'',total:inst.total||0,perPeriod:inst.per_period||0,periods:inst.periods||1});
matrix[idx]={};
var sy=inst.start_year||parseInt(D.profile.start_date.slice(0,4)),sm=inst.start_month||1;
// Apply card month shift
var c=D.cards.find(function(x){return x.name===inst.card});
var monthShift=(c&&inst.billing_day&&inst.billing_day>c.statement_day)?1:0;
for(var p=0;p<inst.periods;p++){
var m=sm-1+p+monthShift,y=sy;
while(m>11){m-=12;y++}
var mk=y+'-'+(m<10?'0':'')+m;
matrix[idx][mk]=inst.per_period}});

// Sort by last payment date > start payment date > name
var lastMonth={},firstMonth={};
for(var li=0;li<instNames.length;li++){
var mks=Object.keys(matrix[li]);mks.sort();
lastMonth[li]=mks.length?mks[mks.length-1]:'9999-99';
firstMonth[li]=mks.length?mks[0]:'9999-99'}
var order=[];for(var i=0;i<instNames.length;i++)order.push(i);
order.sort(function(a,b){var d1=lastMonth[a].localeCompare(lastMonth[b]);if(d1!==0)return d1;var d2=firstMonth[a].localeCompare(firstMonth[b]);if(d2!==0)return d2;return instNames[a].name.localeCompare(instNames[b].name)});

// Render table
var h='<table class="tbl" style="font-size:10px;white-space:nowrap">';
// Header: Month | inst1 | inst2 | ... | Total
h+='<thead><tr><th style="position:sticky;left:0;background:var(--bg3);z-index:1;min-width:70px">Month</th>';
order.forEach(function(idx){
var inf=instNames[idx];
h+='<th class="r" style="min-width:75px;font-size:8px" title="'+esc(inf.name)+'">'+esc(inf.name.length>12?inf.name.slice(0,11)+'\u2026':inf.name)+'</th>'});
h+='<th class="r" style="min-width:80px;font-weight:700;background:var(--primary-bg)">Total</th></tr></thead><tbody>';

// Read threshold
var threshEl=document.getElementById('inst-threshold');
var threshold=threshEl?pn(threshEl.value):10000;
var grandTotal=0;
var colTotals={};order.forEach(function(idx){colTotals[idx]=0});

months.forEach(function(mo){
var mk=mo.y+'-'+(mo.m<10?'0':'')+mo.m;
var rowTotal=0;var hasAny=false;
order.forEach(function(idx){var v=matrix[idx][mk]||0;rowTotal+=v;if(v>0)hasAny=true;colTotals[idx]+=v});
if(!hasAny)return;// skip months with no payments
grandTotal+=rowTotal;
var overThreshold=threshold>0&&rowTotal>threshold;
var isNow=(mo.y===new Date().getFullYear()&&mo.m===new Date().getMonth());
var rowStyle='';var stickyBg='var(--bg2)';
if(isNow&&overThreshold){rowStyle='background:linear-gradient(90deg,rgba(74,122,237,.18),rgba(220,38,38,.12));font-weight:700;border-top:2px solid var(--primary);border-bottom:2px solid var(--primary)';stickyBg='rgba(74,122,237,.18)'}
else if(isNow){rowStyle='background:var(--primary-bg);font-weight:700;border-top:2px solid var(--primary);border-bottom:2px solid var(--primary)';stickyBg='var(--primary-bg)'}
else if(overThreshold){rowStyle='background:var(--error-bg)';stickyBg='var(--error-bg)'}
var nowLabel=isNow?'<span style="display:inline-block;background:var(--primary);color:#fff;font-size:7px;padding:1px 5px;border-radius:8px;margin-right:4px;font-weight:700;letter-spacing:.5px;vertical-align:middle">NOW</span>':'';
h+='<tr style="'+rowStyle+'"><td style="position:sticky;left:0;background:'+stickyBg+';z-index:1;font-weight:600">'+nowLabel+(overThreshold?'\u26a0\ufe0f ':'')+ MO[mo.m]+' '+String(mo.y).slice(2)+'</td>';
order.forEach(function(idx){
var v=matrix[idx][mk]||0;
var cellStyle='font-family:var(--mono);color:'+(v>0?'var(--text)':'var(--border)');
if(isNow&&v>0)cellStyle+=';font-weight:600;color:var(--primary)';
h+='<td class="r" style="'+cellStyle+'">'+
(v>0?'\u0e3f'+fmt(v):'\u2014')+'</td>'});
h+='<td class="r" style="font-family:var(--mono);font-weight:700;color:'+(overThreshold?'#fff':'var(--error)')+';background:'+(overThreshold?'var(--error)':'var(--error-bg)')+';border-radius:'+(overThreshold?'4px':'0')+'">\u0e3f'+fmt(rowTotal)+(overThreshold?' \u26a0\ufe0f':'')+'</td></tr>'});

// Footer: column totals
h+='<tr style="font-weight:700;background:var(--bg3)"><td style="position:sticky;left:0;background:var(--bg3);z-index:1">TOTAL</td>';
order.forEach(function(idx){
h+='<td class="r" style="font-family:var(--mono);font-size:9px">\u0e3f'+fmt(colTotals[idx])+'</td>'});
h+='<td class="r" style="font-family:var(--mono);color:var(--error);font-size:11px">\u0e3f'+fmt(grandTotal)+'</td></tr>';

h+='</tbody></table>';
el.innerHTML=h;

// Highcharts areaspline — render into inst-matrix-chart
var chartDiv=document.getElementById('inst-matrix-chart');
if(!chartDiv||typeof Highcharts==='undefined')return;
// Build chart data from variables already in scope (months, order, matrix, instNames)
var cLabels=[],cTotals=[];
months.forEach(function(mo2){
var mk2=mo2.y+'-'+(mo2.m<10?'0':'')+mo2.m;
var rt2=0;order.forEach(function(idx2){rt2+=matrix[idx2][mk2]||0});
if(rt2>0){cLabels.push(MO[mo2.m]+' '+String(mo2.y).slice(2));cTotals.push(Math.round(rt2*100)/100)}});
if(!cLabels.length){chartDiv.innerHTML='';return}
try{
var dk=document.documentElement.classList.contains('dark');
var tc=dk?'#e8eaed':'#1a1d27',tc2=dk?'#6b7185':'#7a8098',gc=dk?'#353849':'#d4d7e0',bg2=dk?'#1a1d27':'#fff';
var sc=dk?'#f87171':'#dc2626';
Highcharts.chart(chartDiv,{
chart:{type:'areaspline',backgroundColor:'transparent',height:280},
title:{text:'Monthly Installment Payments',style:{color:tc,fontWeight:'600',fontSize:'13px'}},
xAxis:{categories:cLabels,labels:{style:{color:tc2,fontSize:'9px'},rotation:-45},lineColor:gc},
yAxis:{title:{text:null},labels:{style:{color:tc2,fontSize:'9px'},formatter:function(){return'\u0e3f'+Highcharts.numberFormat(this.value/1000,0)+'K'}},gridLineColor:gc,min:0,
plotLines:threshold>0?[{color:dk?'#fbbf24':'#d97706',width:2,value:threshold,dashStyle:'ShortDash',label:{text:'Threshold \u0e3f'+fmt(threshold),style:{color:dk?'#fbbf24':'#d97706',fontSize:'9px',fontWeight:'600'},align:'right'},zIndex:4}]:[]},
tooltip:{backgroundColor:bg2,borderColor:gc,style:{color:tc,fontSize:'10px'},
pointFormat:'\u0e3f{point.y:,.2f}'},
plotOptions:{areaspline:{marker:{enabled:false,states:{hover:{enabled:true,radius:3}}}}},
series:[{name:'Installment Total',data:cTotals,color:sc,
fillColor:{linearGradient:{x1:0,y1:0,x2:0,y2:1},stops:[[0,sc+'40'],[1,sc+'05']]},
lineWidth:2}],
legend:{enabled:false},credits:{enabled:false}});
}catch(ce){console.error('InstChart:',ce)}
}


function renderPlanned(){
if(!D||!D.planned)return;
document.getElementById('planned-hdr').innerHTML='<th style="width:24px"><input type="checkbox" onchange="toggleAllPlanned(this.checked)"></th>'+pSH('name','Name')+'<th>I/E</th>'+pSH('type','Type')+pSH('amount','Amount')+'<th>Date</th><th>Card</th><th>Own By</th><th>Notes</th><th></th>';
document.getElementById('planned-body').innerHTML=D.planned.map(function(p,i){
var dirCls=p.direction==='income'?'color:var(--success);font-weight:600':'';
return '<tr style="'+(p.direction==='income'?'background:rgba(16,185,129,0.05)':'')+'"><td><input type="checkbox" class="pl-chk" data-idx="'+i+'" onchange="updatePlannedBulk()"></td>'+
'<td><input class="inp-inline" value="'+esc(p.name)+'" data-pli="'+i+'" data-f="name"></td>'+
'<td><select class="sel" style="'+dirCls+'" data-pli="'+i+'" data-f="direction">'+dirOpts(p.direction)+'</select></td>'+
'<td><select class="sel" data-pli="'+i+'" data-f="type">'+tOpts(p.type)+'</select></td>'+
'<td class="r"><input class="inp inp-num" type="text" value="'+fmt(p.amount)+'" style="width:80px;padding:2px 4px;font-size:10px" data-pli="'+i+'" data-f="amount" onfocus="var v=parseFloat(this.value.replace(/,/g,\'\'));this.value=v||\'\';" onblur="this.value=(parseFloat(this.value.replace(/,/g,\'\'))||0).toLocaleString(\'en-US\',{minimumFractionDigits:2,maximumFractionDigits:2})"></td>'+
'<td><input type="date" class="inp" value="'+(p.date||'')+'" style="width:110px;padding:2px 4px;font-size:10px" data-pli="'+i+'" data-f="date"></td>'+
'<td><select class="sel" data-pli="'+i+'" data-f="card">'+cOpts(p.card)+'</select></td>'+
'<td><select class="sel" data-pli="'+i+'" data-f="own_by">'+oOpts(p.own_by)+'</select></td>'+
'<td><input class="inp-inline" value="'+esc(p.notes||'')+'" data-pli="'+i+'" data-f="notes" style="font-size:9px;width:80px"></td>'+
'<td><button class="del-btn" onclick="readAll();D.planned.splice('+i+',1);renderPlanned();filterPlanned()"><i class="fa-solid fa-trash"></i></button></td></tr>'}).join('');
populatePlannedFilters()}


function addPlanned(){readAll();D.planned.push({name:'New',type:D.types[0]||'Other',amount:0,date:'',card:'Cash/Direct',direction:'expense',own_by:'Me',notes:''});renderPlanned();filterPlanned()}

function toggleAllPlanned(c){document.querySelectorAll('.pl-chk').forEach(function(cb){var tr=cb.closest('tr');if(tr&&tr.style.display!=='none')cb.checked=c});updatePlannedBulk()}
function updatePlannedBulk(){var n=document.querySelectorAll('.pl-chk:checked').length;var el=document.getElementById('planned-bulk');if(el)el.style.display=n>0?'':'none';var c=document.getElementById('pl-sel-count');if(c)c.textContent=n}
function deleteSelectedPlanned(){var idxs=[];document.querySelectorAll('.pl-chk:checked').forEach(function(cb){idxs.push(parseInt(cb.dataset.idx))});if(!idxs.length)return;if(!confirm('Delete '+idxs.length+' planned item(s)?'))return;readAll();idxs.sort(function(a,b){return b-a});idxs.forEach(function(i){D.planned.splice(i,1)});saveD();renderPlanned();filterPlanned();toast('\ud83d\uddd1\ufe0f Deleted '+idxs.length+' item(s)')}


function sortPlanned(col){
var st=plannedSortState;if(st.col===col)st.asc=!st.asc;else{st.col=col;st.asc=true}
D.planned.sort(function(a,b){
var va=a[col],vb=b[col];
if(typeof va==='number'&&typeof vb==='number')return st.asc?va-vb:vb-va;
va=String(va||'').toLowerCase();vb=String(vb||'').toLowerCase();
return st.asc?va.localeCompare(vb):vb.localeCompare(va)});
renderPlanned();filterPlanned()}


function populatePlannedFilters(){
var types={},cards={};
D.planned.forEach(function(p){types[p.type]=1;if(p.card)cards[p.card]=1});
var ft=document.getElementById('flt-p-type'),fc=document.getElementById('flt-p-card');
if(ft){var cv=ft.value;ft.innerHTML='<option value="">All Types</option>'+Object.keys(types).sort().map(function(t){return '<option'+(cv===t?' selected':'')+'>'+esc(t)+'</option>'}).join('')}
if(fc){var cv2=fc.value;fc.innerHTML='<option value="">All Cards</option>'+Object.keys(cards).sort().map(function(c){return '<option'+(cv2===c?' selected':'')+'>'+esc(c)+'</option>'}).join('')}}


function filterPlanned(){var ft=document.getElementById('flt-p-type').value,fc=document.getElementById('flt-p-card').value;
document.querySelectorAll('#planned-body tr').forEach(function(tr,i){
if(!D.planned[i]){tr.style.display='';return}
var show=true;if(ft&&D.planned[i].type!==ft)show=false;if(fc&&D.planned[i].card!==fc)show=false;
tr.style.display=show?'':'none'})}


function populateInstDropdown(){
var sel=document.getElementById('inst-from-recurring');if(!sel)return;
var items=[];
D.yearly.forEach(function(y,yi){
if(y.pay_mode==='installment'){
items.push({idx:yi,name:y.name,type:y.type||'Other',amount:y.amount,month:y.month||1,day:y.billing_day||1,periods:y.inst_periods||1,card:y.card||''})}});
items.sort(function(a,b){
var tc=a.type.localeCompare(b.type);if(tc!==0)return tc;
if(a.month!==b.month)return a.month-b.month;
if(a.day!==b.day)return a.day-b.day;
return a.name.localeCompare(b.name)});
var h='<option value="">\u2014 Select from Recurring (installment only) \u2014</option>';
var lastType='';
items.forEach(function(it){
var pp=it.periods>0?Math.round(it.amount/it.periods*100)/100:it.amount;
if(it.type!==lastType){if(lastType)h+='</optgroup>';h+='<optgroup label="'+esc(it.type)+'">';lastType=it.type}
h+='<option value="'+it.idx+'">'+esc(it.name)+' ('+MO[it.month-1]+', '+it.periods+'x \u0e3f'+fmt(pp)+'/mo, total \u0e3f'+fmt(it.amount)+')</option>'});
if(lastType)h+='</optgroup>';
sel.innerHTML=h}


function addInstFromRecurring(){
readAll();
var sel=document.getElementById('inst-from-recurring');
var yi=sel?parseInt(sel.value):NaN;
if(isNaN(yi)){toast('\u26a0\ufe0f Select a recurring item first');return}
var y=D.yearly[yi];if(!y){toast('\u26a0\ufe0f Item not found');return}
D.installments.push({
name:y.name,
type:y.type||'Other',
card:y.card||'',
own_by:y.own_by||'Me',
total:y.amount,
per_period:y.inst_periods>0?Math.round(y.amount/y.inst_periods*100)/100:y.amount,
periods:y.inst_periods||1,
start_year:parseInt(D.profile.start_date.slice(0,4)),
start_month:y.month||1,
status:'Active'});
instSortState.col=null;
saveAll();
toast('\u2705 Added '+y.name)}


function convertAutoInst(yearlyIdx){
readAll();
var autoItems=[];
D.yearly.forEach(function(y,yi){if(y.pay_mode==='installment'){autoItems.push({yi:yi,y:y})}});
if(yearlyIdx<0||yearlyIdx>=autoItems.length)return;
var item=autoItems[yearlyIdx];
var y=item.y;
var pp=y.inst_periods>0?Math.round(y.amount/y.inst_periods*100)/100:y.amount;
D.installments.push({
name:y.name,type:y.type||'Other',card:y.card||'',own_by:y.own_by||'Me',
total:y.amount,per_period:pp,periods:y.inst_periods||1,
start_year:y.month>=new Date().getMonth()+1?parseInt(D.profile.start_date.slice(0,4)):parseInt(D.profile.start_date.slice(0,4))+1,
start_month:y.month||1,status:'Planned'});
D.yearly[item.yi].pay_mode='full';
D.yearly[item.yi].inst_periods=1;
saveD();simulate();renderAllTabs();
toast('\u2705 Converted to editable installment')}


function addInst(){readAll();D.installments.push({name:'New',type:D.types[0]||'Other',card:D.cards[0]?D.cards[0].name:'',own_by:'Me',total:0,per_period:0,periods:1,start_year:new Date().getFullYear(),start_month:new Date().getMonth()+1,start_day:1,billing_day:1,status:'Planned'});instSortState.col=null;renderInst();filterInst()}


// === SIMULATION ===

function renderCardDetail(){
var el=document.getElementById('card-detail');
if(!el||!D||!D.cards||!D.monthly||!D.installments||!D.yearly)return;
var instItems=[];
D.installments.forEach(function(inst){if(inst&&(inst.status==='Active'||inst.status==='Planned'))instItems.push(inst)});
D.yearly.forEach(function(y){if(y&&y.pay_mode==='installment'){
var pp=(y.inst_periods&&y.inst_periods>0)?Math.round(y.amount/y.inst_periods*100)/100:(y.amount||0);
instItems.push({name:y.name||'',card:y.card||'',per_period:pp,source:'Yearly'})}});
var h='<h3 style="font-size:12px;font-weight:600;margin:8px 0 6px;color:var(--text2)">Card Load Breakdown</h3>';
D.cards.forEach(function(c){
var mItems=D.monthly.filter(function(m){return m.card===c.name});
var iItems=instItems.filter(function(x){return x.card===c.name});
var mLoad=mItems.reduce(function(s,x){return s+(x.amount||0)},0);
var iLoad=iItems.reduce(function(s,x){return s+(x.per_period||0)},0);
var total=mLoad+iLoad;
if(total===0)return;
h+='<div class="acc-header" onclick="this.querySelector(\'.arr\').classList.toggle(\'open\');this.nextElementSibling.classList.toggle(\'open\')">'+
'<span class="arr">\u25b6</span><span style="flex:1;font-weight:600;font-size:11px">'+esc(c.name)+'</span>'+
'<span style="font-size:9px;color:var(--text3)">Pay: '+ord(c.payment_day||1)+' | Due: '+ord(c.deadline||1)+'</span>'+
'<span style="font-family:var(--mono);font-size:11px;font-weight:600;min-width:80px;text-align:right">\u0e3f'+fmt(total)+'/mo</span></div>'+
'<div class="acc-body">';
mItems.forEach(function(m){h+='<div class="day-row" style="padding-left:28px"><span class="day-icon">\ud83d\udccb</span><span class="day-name" style="font-size:10px">'+esc(m.name)+'</span><span style="font-size:9px;color:var(--text3)">Monthly</span><span class="day-amt" style="font-size:10px">\u0e3f'+fmt(m.amount)+'</span></div>'});
iItems.forEach(function(x){h+='<div class="day-row" style="padding-left:28px"><span class="day-icon">\ud83d\udcb3</span><span class="day-name" style="font-size:10px">'+esc(x.name)+'</span><span style="font-size:9px;color:var(--text3)">'+(x.source||'')+'</span><span class="day-amt" style="font-size:10px">\u0e3f'+fmt(x.per_period)+'</span></div>'});
h+='</div>'});
el.innerHTML=h}


function renderRecurringSummary(){
if(!D||!D.monthly||!D.yearly)return;
var mExp=D.monthly.filter(function(m){return m.direction!=='income'}).reduce(function(s,m){return s+m.amount},0);
var mInc=D.monthly.filter(function(m){return m.direction==='income'}).reduce(function(s,m){return s+m.amount},0);
var yExp=D.yearly.filter(function(y){return y.direction!=='income'}).reduce(function(s,y){return s+y.amount},0);
var yInc=D.yearly.filter(function(y){return y.direction==='income'}).reduce(function(s,y){return s+y.amount},0);
var mTotal=mExp+mInc;var yTotal=yExp+yInc;
var normalPay=computePayroll(1);var annualIncome=normalPay.net*12;
var bonusPay=computePayroll(12);annualIncome+=(bonusPay.net-normalPay.net);
var annExp=mExp*12+yExp;var annInc=mInc*12+yInc;
document.getElementById('recurring-kpis').innerHTML=
'<div class="kpi"><div class="kpi-label">Monthly Items</div><div class="kpi-val">'+D.monthly.length+'</div><div class="kpi-note">\u0e3f'+fmt(mTotal)+'/mo</div></div>'+
'<div class="kpi"><div class="kpi-label">Yearly Items</div><div class="kpi-val">'+D.yearly.length+'</div><div class="kpi-note">\u0e3f'+fmt(yTotal)+'/yr</div></div>'+
'<div class="kpi"><div class="kpi-label">Annual Expenses</div><div class="kpi-val text-error">\u0e3f'+fmt(annExp)+'</div><div class="kpi-note">'+(annualIncome>0?((annExp)/annualIncome*100).toFixed(1)+'% of income':'')+'</div></div>'+
(annInc>0?'<div class="kpi"><div class="kpi-label">Annual Recurring Income</div><div class="kpi-val text-success">\u0e3f'+fmt(annInc)+'</div></div>':'')+
'<div class="kpi"><div class="kpi-label">Net Eff. Monthly</div><div class="kpi-val text-primary">\u0e3f'+fmt(mExp-mInc+(yExp-yInc)/12)+'</div><div class="kpi-note">'+(normalPay.net>0?((mExp-mInc+(yExp-yInc)/12)/normalPay.net*100).toFixed(1)+'% of net pay':'')+'</div></div>';

var groupBy=(document.getElementById('summary-group')||{}).value||'type';
var allItems=[];
D.monthly.forEach(function(m){allItems.push({name:m.name,type:m.type,card:m.card,amount:m.amount,freq:'Monthly',annual:m.amount*12,direction:m.direction||'expense'})});
D.yearly.forEach(function(y){allItems.push({name:y.name,type:y.type,card:y.card,amount:y.amount,freq:'Yearly',annual:y.amount,direction:y.direction||'expense'})});

var groups={};
allItems.forEach(function(it){
var key=groupBy==='type'?it.type:groupBy==='card'?it.card:it.freq;
if(!groups[key])groups[key]={items:[],total:0};
groups[key].items.push(it);groups[key].total+=it.annual});

var gKeys=Object.keys(groups).sort();
var h='';
gKeys.forEach(function(gk,gi){var g=groups[gk];
h+='<div class="acc-header" onclick="this.querySelector(\'.arr\').classList.toggle(\'open\');this.nextElementSibling.classList.toggle(\'open\')">'+
'<span class="arr">\u25b6</span><span style="flex:1;font-weight:600;font-size:12px">'+esc(gk)+'</span>'+
'<span style="font-size:10px;color:var(--text3)">'+g.items.length+' items</span>'+
'<span style="font-size:9px;color:var(--text3);margin-right:8px">'+(annualIncome>0?(g.total/annualIncome*100).toFixed(1)+'%':'')+'</span>'+
'<span style="font-family:var(--mono);font-size:11px;font-weight:600;min-width:90px;text-align:right">\u0e3f'+fmt(g.total)+'/yr</span></div>'+
'<div class="acc-body">';
g.items.sort(function(a,b){return b.annual-a.annual}).forEach(function(it){
var dirBadge=it.direction==='income'?'<span style="font-size:8px;padding:1px 4px;border-radius:6px;background:var(--success);color:#fff;margin-right:4px">Income</span>':'';
h+='<div class="day-row" style="padding-left:32px">'+dirBadge+'<span class="day-name" style="font-size:11px">'+esc(it.name)+'</span>'+
'<span style="font-size:9px;color:var(--text3);margin:0 6px">'+esc(it.freq)+'</span>'+
'<span class="day-amt" style="font-size:10px">\u0e3f'+fmt(it.amount)+(it.freq==='Monthly'?'/mo':'/yr')+'</span>'+
'<span style="font-size:9px;color:var(--text3);min-width:35px;text-align:right;margin-right:4px">'+(annualIncome>0?(it.annual/annualIncome*100).toFixed(1)+'%':'')+'</span>'+
'<span class="day-bal" style="font-size:10px;min-width:80px">\u0e3f'+fmt(it.annual)+'/yr</span></div>'});
h+='</div>'});
document.getElementById('recurring-groups').innerHTML=h}


var sortState={monthly:{col:null,asc:true},yearly:{col:null,asc:true},payroll:{col:null,asc:true}};

function sortTable(table,col){
var st=sortState[table];
if(st.col===col)st.asc=!st.asc;else{st.col=col;st.asc=true}
var arr=table==='monthly'?D.monthly:table==='yearly'?D.yearly:D.payroll;
arr.sort(function(a,b){var va,vb;
if(table==='yearly'&&(col==='billing_day'||col==='month')){va=(a.month||0)*100+(a.billing_day||0);vb=(b.month||0)*100+(b.billing_day||0);return st.asc?va-vb:vb-va}
va=a[col];vb=b[col];
if(typeof va==='number'&&typeof vb==='number')return st.asc?va-vb:vb-va;
va=String(va||'').toLowerCase();vb=String(vb||'').toLowerCase();
return st.asc?va.localeCompare(vb):vb.localeCompare(va)});
if(table==='monthly'){renderMonthly();filterMonthly()}
else if(table==='yearly'){renderYearly();filterYearly()}
else renderPayroll()}


function sHdr(table,col,label){
var st=sortState[table];
var arrow=st.col===col?(st.asc?' \u25b2':' \u25bc'):'';
return '<th style="cursor:pointer" onclick="readAll();sortTable(\''+table+'\',\''+col+'\')" '+(col==='amount'||col==='billing_day'||col==='inst_periods'||col==='month'?'class="r"':'')+'>'+label+arrow+'</th>'}



function populateFilters(){
var tOpts=sTypes().map(function(t){return '<option>'+esc(t)+'</option>'}).join('');
var cOpts2=sCards().map(function(c){return '<option>'+esc(c.name)+'</option>'}).join('');
['flt-m-type','flt-y-type','flt-i-type'].forEach(function(id){var el=document.getElementById(id);if(el){var v=el.value;el.innerHTML='<option value="">All Types</option>'+tOpts;el.value=v}});
['flt-m-card','flt-y-card','flt-i-card'].forEach(function(id){var el=document.getElementById(id);if(el){var v=el.value;el.innerHTML='<option value="">All Cards</option><option value="Cash/Direct">Cash/Direct</option>'+cOpts2;el.value=v}});
var sOpts=STATUSES.map(function(s){return '<option>'+s+'</option>'}).join('');
var el=document.getElementById('flt-i-status');if(el){var v=el.value;el.innerHTML='<option value="">All Status</option>'+sOpts;el.value=v}
var el2=document.getElementById('flt-i-source');if(el2){var v=el2.value;el2.innerHTML='<option value="">All Sources</option><option>Manual</option><option>Yearly</option>';el2.value=v}
var el3=document.getElementById('flt-i-owner');if(el3){var v=el3.value;el3.innerHTML='<option value="">All Owners</option>'+(D.owners||[]).slice().sort().map(function(o){return '<option>'+o+'</option>'}).join('');el3.value=v}}


function filterMonthly(){var ft=document.getElementById('flt-m-type').value,fc=document.getElementById('flt-m-card').value;
document.querySelectorAll('#monthly-body tr').forEach(function(tr,i){
if(!D.monthly[i]){tr.style.display='';return}
var show=true;if(ft&&D.monthly[i].type!==ft)show=false;if(fc&&D.monthly[i].card!==fc)show=false;
tr.style.display=show?'':'none'})}


function filterYearly(){var ft=document.getElementById('flt-y-type').value,fm=document.getElementById('flt-y-mode').value,fc=document.getElementById('flt-y-card').value;
document.querySelectorAll('#yearly-body tr').forEach(function(tr,i){
if(!D.yearly[i]){tr.style.display='';return}
var show=true;if(ft&&D.yearly[i].type!==ft)show=false;if(fm&&D.yearly[i].pay_mode!==fm)show=false;if(fc&&D.yearly[i].card!==fc)show=false;
tr.style.display=show?'':'none'})}


function filterInst(){var ft=document.getElementById('flt-i-type').value,fc=document.getElementById('flt-i-card').value,
fs=document.getElementById('flt-i-status').value,fsr=document.getElementById('flt-i-source').value,fo=document.getElementById('flt-i-owner').value;
var all=allInstallments();
document.querySelectorAll('#inst-body tr').forEach(function(tr){
var idx=parseInt(tr.dataset.idx);if(isNaN(idx)||!all[idx]){tr.style.display='';return}var it=all[idx];var show=true;
if(ft&&it.type!==ft)show=false;if(fc&&it.card!==fc)show=false;
if(fs&&it.status!==fs)show=false;if(fsr&&it.source!==fsr)show=false;if(fo&&it.own_by!==fo)show=false;
tr.style.display=show?'':'none';
if(!show){var cb=tr.querySelector('.inst-chk');if(cb)cb.checked=false}});
var sa=document.getElementById('inst-select-all');if(sa)sa.checked=false;
updateInstBulkActions()}

var HELP_LANG='en';
var HELP_DATA={
en:{
title:'Help & Reference',
sso_title:'Thai Social Security (SSO) — Contribution Rules',
legal:'<strong>Legal Basis:</strong> Social Security Act B.E. 2533 (1990), Section 33<br><strong>Governing Body:</strong> Social Security Office (SSO), Ministry of Labour<br><strong>Applies to:</strong> All private-sector employees aged 15\u201360, including foreign workers with work permits',
rate_title:'Contribution Rate',
rate_tbl:'<tr><td>Employee</td><td class="r" style="font-family:var(--mono)">5%</td><td>Deducted from salary each month</td></tr><tr><td>Employer</td><td class="r" style="font-family:var(--mono)">5%</td><td>Matching contribution, paid separately</td></tr><tr><td>Government</td><td class="r" style="font-family:var(--mono)">2.75%</td><td>Paid by the state</td></tr>',
rate_hdr:'<tr><th>Party</th><th class="r">Rate</th><th>Notes</th></tr>',
ceil_title:'Wage Ceiling (Multi-Year Reform)',
ceil_hdr:'<tr><th>Phase</th><th>Period</th><th class="r">Wage Ceiling</th><th class="r">Max/party</th><th class="r">Total Max</th></tr>',
ceil_tbl:'<tr><td><span class="tag tag-finished">Old</span></td><td>Before 2026</td><td class="r" style="font-family:var(--mono)">\u0e3f15,000</td><td class="r" style="font-family:var(--mono)">\u0e3f750</td><td class="r" style="font-family:var(--mono)">\u0e3f1,500</td></tr><tr style="background:var(--success-bg)"><td><span class="tag tag-active">Phase 1</span></td><td>Jan 2026 \u2013 Dec 2028</td><td class="r" style="font-family:var(--mono)">\u0e3f17,500</td><td class="r" style="font-family:var(--mono)">\u0e3f875</td><td class="r" style="font-family:var(--mono)">\u0e3f1,750</td></tr><tr><td><span class="tag tag-planned">Phase 2</span></td><td>Jan 2029 \u2013 Dec 2031</td><td class="r" style="font-family:var(--mono)">\u0e3f20,000</td><td class="r" style="font-family:var(--mono)">\u0e3f1,000</td><td class="r" style="font-family:var(--mono)">\u0e3f2,000</td></tr><tr><td><span class="tag tag-planned">Phase 3</span></td><td>From Jan 2032</td><td class="r" style="font-family:var(--mono)">\u0e3f23,000</td><td class="r" style="font-family:var(--mono)">\u0e3f1,150</td><td class="r" style="font-family:var(--mono)">\u0e3f2,300</td></tr>',
ceil_note:'Minimum wage floor: \u0e3f1,650/month. Published in Royal Gazette: 12 Dec 2025.',
calc_title:'Calculation Formula',
calc_body:'<strong>Contribution Base</strong> = min(Monthly Salary, Wage Ceiling)<br><strong>Employee SSO</strong> = Contribution Base \u00d7 5%<br><strong>Cap Rule:</strong> If salary \u2265 \u0e3f17,500 \u2192 contribution = \u0e3f875 (max)<br><strong>Cap Rule:</strong> If salary &lt; \u0e3f1,650 \u2192 uses \u0e3f1,650 floor<br><br><strong>Examples (2026):</strong><br>Salary \u0e3f10,000 \u2192 10,000 \u00d7 5% = <strong>\u0e3f500</strong><br>Salary \u0e3f15,000 \u2192 15,000 \u00d7 5% = <strong>\u0e3f750</strong><br>Salary \u0e3f17,500 \u2192 17,500 \u00d7 5% = <strong>\u0e3f875</strong> (at ceiling)<br>Salary \u0e3f62,566 \u2192 17,500 \u00d7 5% = <strong>\u0e3f875</strong> (capped)',
setup_title:'How to Set Up in This App',
setup_body:'<ol style="padding-left:18px;margin-bottom:8px"><li>Go to <strong>Payroll</strong> tab</li><li>For <strong>Income items</strong>: check the <strong>SSO</strong> checkbox on items included in SSO wage base</li><li>For <strong>Social Security deduction</strong>: set Calc Mode to <strong>"% of SSO Base"</strong>, Rate = <strong>5%</strong>, Cap = <strong>\u0e3f875</strong></li><li>The app calculates: min(SSO Base \u00d7 5%, \u0e3f875) each month</li></ol><p style="font-size:10px;color:var(--text3)">Note: Bonus/OT may or may not be in SSO base. Consult HR.</p>',
benefit_title:'SSO Benefits (2026 rates)',
benefit_hdr:'<tr><th>Benefit</th><th class="r">Before 2026</th><th class="r">From Jan 2026</th></tr>',
benefit_tbl:'<tr><td>Sickness/Disability/Unemployment (mo.)</td><td class="r" style="font-family:var(--mono)">\u0e3f7,500</td><td class="r" style="font-family:var(--mono)">\u0e3f8,750</td></tr><tr><td>Maternity/Childbirth (per birth)</td><td class="r" style="font-family:var(--mono)">\u0e3f22,500</td><td class="r" style="font-family:var(--mono)">\u0e3f26,250</td></tr><tr><td>Death Lump-sum</td><td class="r" style="font-family:var(--mono)">\u0e3f90,000</td><td class="r" style="font-family:var(--mono)">\u0e3f105,000</td></tr><tr><td>Pension (15 yrs)</td><td class="r" style="font-family:var(--mono)">\u0e3f3,000/mo</td><td class="r" style="font-family:var(--mono)">\u0e3f3,500/mo</td></tr><tr><td>Pension (25+ yrs)</td><td class="r" style="font-family:var(--mono)">\u0e3f5,250/mo</td><td class="r" style="font-family:var(--mono)">\u0e3f6,125/mo</td></tr>',
compliance_title:'Key Compliance Points',
compliance:'<li>Contributions due by <strong>15th of the following month</strong></li><li>Late penalty: <strong>2% per month</strong> surcharge</li><li>Employee must be registered within <strong>30 days</strong> of start date</li><li>Coverage starts from <strong>first day of employment</strong></li><li>Foreign employees with work permits are <strong>not exempt</strong></li>',
tax_title:'Thai Personal Income Tax',
tax_rates:'<table class="tbl" style="margin-bottom:10px"><thead><tr><th>Net Taxable Income (THB)</th><th class="r">Rate</th><th class="r">Max Tax</th></tr></thead><tbody>'+
'<tr><td>0 - 150,000</td><td class="r">Exempt</td><td class="r">0</td></tr>'+
'<tr><td>150,001 - 300,000</td><td class="r">5%</td><td class="r">7,500</td></tr>'+
'<tr><td>300,001 - 500,000</td><td class="r">10%</td><td class="r">20,000</td></tr>'+
'<tr><td>500,001 - 750,000</td><td class="r">15%</td><td class="r">37,500</td></tr>'+
'<tr><td>750,001 - 1,000,000</td><td class="r">20%</td><td class="r">50,000</td></tr>'+
'<tr><td>1,000,001 - 2,000,000</td><td class="r">25%</td><td class="r">250,000</td></tr>'+
'<tr><td>2,000,001 - 5,000,000</td><td class="r">30%</td><td class="r">900,000</td></tr>'+
'<tr><td>5,000,001+</td><td class="r">35%</td><td class="r">-</td></tr></tbody></table>',
tax_formula:'<strong>Taxable Income</strong> = Assessable Income - Expenses (50%, max \u0e3f100K) - Exemptions<br><strong>Tax</strong> = Apply progressive rates to Taxable Income',
tax_exemptions_title:'Tax Exemptions & Deductions Reference',
tax_exemptions_detail:'<table class="tbl" style="margin-bottom:10px;font-size:10px"><thead><tr><th>Exemption</th><th class="r">Max (\u0e3f)</th><th>Details & Conditions</th></tr></thead><tbody>'+
'<tr><td><strong>Personal Allowance</strong></td><td class="r">60,000</td><td>Every taxpayer. No conditions.</td></tr>'+
'<tr><td><strong>Spouse Allowance</strong></td><td class="r">60,000</td><td>Spouse with no income or files jointly.</td></tr>'+
'<tr><td><strong>Child Allowance</strong></td><td class="r">30,000/child</td><td>Legitimate children. 2nd child born 2018+ gets \u0e3f60,000. Max unlimited children.</td></tr>'+
'<tr><td><strong>Parental Care</strong></td><td class="r">30,000/person</td><td>Parents aged 60+ with income under \u0e3f30,000/yr. Max 4 persons (yours + spouse\'s).</td></tr>'+
'<tr><td><strong>Disability Care</strong></td><td class="r">60,000</td><td>Caring for a disabled family member.</td></tr>'+
'<tr style="background:var(--bg3)"><td colspan="3"><strong>\u2014 Employment Deductions \u2014</strong></td></tr>'+
'<tr><td><strong>Expense Deduction</strong></td><td class="r">100,000</td><td>50% of employment income, max \u0e3f100,000. Auto-calculated.</td></tr>'+
'<tr style="background:var(--bg3)"><td colspan="3"><strong>\u2014 Insurance & Savings \u2014</strong></td></tr>'+
'<tr><td><strong>Life Insurance Premium</strong></td><td class="r">100,000</td><td>Premiums paid to Thai-licensed insurer. Policy must be 10+ years. Combined with health insurance max \u0e3f100,000.</td></tr>'+
'<tr><td><strong>Health Insurance</strong></td><td class="r">25,000</td><td>Self only. Combined with life insurance cannot exceed \u0e3f100,000 total.</td></tr>'+
'<tr><td><strong>Spouse Life Insurance</strong></td><td class="r">10,000</td><td>Premiums for spouse\'s life insurance if spouse has no income.</td></tr>'+
'<tr><td><strong>Parents\' Health Insurance</strong></td><td class="r">15,000</td><td>Per parent. Health insurance premiums for parents (yours or spouse\'s). Parent income under \u0e3f30,000/yr.</td></tr>'+
'<tr><td><strong>Social Security (SSO)</strong></td><td class="r">10,500</td><td>Section 33: 5% of wages, ceiling \u0e3f17,500 (2026\u20132028). Max \u0e3f875/month = \u0e3f10,500/year. Auto-calculated from payroll.</td></tr>'+
'<tr><td><strong>Provident Fund (PVD)</strong></td><td class="r">500,000</td><td>Employee contribution, max 15% of salary. Amount exceeding \u0e3f10,000 is deductible up to \u0e3f490,000.</td></tr>'+
'<tr style="background:var(--bg3)"><td colspan="3"><strong>\u2014 Investment Funds (combined max \u0e3f500,000) \u2014</strong></td></tr>'+
'<tr><td><strong>RMF (Retirement Mutual Fund)</strong></td><td class="r">500,000</td><td>Max 30% of assessable income. Must invest continuously until age 55. Combined with PVD, SSF, Thai ESG, PVD cannot exceed \u0e3f500,000.</td></tr>'+
'<tr><td><strong>SSF (Super Savings Fund)</strong></td><td class="r">200,000</td><td>Max 30% of assessable income, max \u0e3f200,000. Hold 10+ years. Combined with RMF, PVD, Thai ESG cannot exceed \u0e3f500,000.</td></tr>'+
'<tr><td><strong>Thai ESG Fund</strong></td><td class="r">300,000</td><td>Max 30% of assessable income, max \u0e3f300,000. Hold 8+ years (bought 2024\u20132026). Combined cap \u0e3f500,000 with RMF/SSF/PVD.</td></tr>'+
'<tr style="background:var(--bg3)"><td colspan="3"><strong>\u2014 Property & Donations \u2014</strong></td></tr>'+
'<tr><td><strong>Home Loan Interest</strong></td><td class="r">100,000</td><td>Interest on mortgage for self-occupied property. Lender must be Thai financial institution. <strong>Multiple borrowers:</strong> the \u0e3f100,000 cap is split equally among all co-borrowers — e.g., 2 co-borrowers = \u0e3f50,000 each; 3 co-borrowers = \u0e3f33,333 each. Multiple properties allowed but combined deduction still max \u0e3f100,000 per person.</td></tr>'+
'<tr><td><strong>First Home Buyer</strong></td><td class="r">200,000</td><td>House value up to \u0e3f5M. Deduct 20% over 5 years (\u0e3f200,000/yr). Specific scheme periods apply.</td></tr>'+
'<tr><td><strong>General Donation</strong></td><td class="r">10% of net</td><td>Donations to qualified charities, temples, hospitals. Max 10% of income after all other deductions.</td></tr>'+
'<tr><td><strong>Education Donation</strong></td><td class="r">2x amount</td><td>Donations to approved educational institutions. Deduct 2x actual amount, combined with general donation max 10%.</td></tr>'+
'<tr><td><strong>Political Party Donation</strong></td><td class="r">10,000</td><td>Donations to registered political parties.</td></tr>'+
'<tr style="background:var(--bg3)"><td colspan="3"><strong>\u2014 Stimulus Measures \u2014</strong></td></tr>'+
'<tr><td><strong>Shopping Stimulus (Easy E-Receipt)</strong></td><td class="r">50,000</td><td>Purchases with e-tax invoice/e-receipt during qualifying period. Varies by tax year.</td></tr>'+
'<tr><td><strong>Domestic Travel</strong></td><td class="r">15,000</td><td>Hotel accommodation in Thailand during qualifying period. Requires receipts.</td></tr>'+
'</tbody></table>'+
'<div style="font-size:9px;color:var(--text3);margin-top:4px"><strong>Note:</strong> Combined cap for RMF + SSF + Thai ESG + PVD = \u0e3f500,000. Life + Health insurance combined max \u0e3f100,000. Amounts and conditions based on Revenue Code and 2026 regulations. Always verify with the Revenue Department or a tax advisor.</div>',
sources_title:'Sources'
},
th:{
title:'\u0e04\u0e39\u0e48\u0e21\u0e37\u0e2d\u0e41\u0e25\u0e30\u0e02\u0e49\u0e2d\u0e21\u0e39\u0e25\u0e2d\u0e49\u0e32\u0e07\u0e2d\u0e34\u0e07',
sso_title:'\u0e1b\u0e23\u0e30\u0e01\u0e31\u0e19\u0e2a\u0e31\u0e07\u0e04\u0e21 (SSO) \u2014 \u0e2b\u0e25\u0e31\u0e01\u0e40\u0e01\u0e13\u0e11\u0e4c\u0e01\u0e32\u0e23\u0e04\u0e33\u0e19\u0e27\u0e13',
legal:'<strong>\u0e2b\u0e25\u0e31\u0e01\u0e01\u0e0e\u0e2b\u0e21\u0e32\u0e22:</strong> \u0e1e.\u0e23.\u0e1a.\u0e1b\u0e23\u0e30\u0e01\u0e31\u0e19\u0e2a\u0e31\u0e07\u0e04\u0e21 \u0e1e.\u0e28. 2533 \u0e21\u0e32\u0e15\u0e23\u0e32 33<br><strong>\u0e2b\u0e19\u0e48\u0e27\u0e22\u0e07\u0e32\u0e19:</strong> \u0e2a\u0e33\u0e19\u0e31\u0e01\u0e07\u0e32\u0e19\u0e1b\u0e23\u0e30\u0e01\u0e31\u0e19\u0e2a\u0e31\u0e07\u0e04\u0e21 (\u0e2a\u0e1b\u0e2a.) \u0e01\u0e23\u0e30\u0e17\u0e23\u0e27\u0e07\u0e41\u0e23\u0e07\u0e07\u0e32\u0e19<br><strong>\u0e1c\u0e39\u0e49\u0e1b\u0e23\u0e30\u0e01\u0e31\u0e19\u0e15\u0e19:</strong> \u0e25\u0e39\u0e01\u0e08\u0e49\u0e32\u0e07\u0e20\u0e32\u0e04\u0e40\u0e2d\u0e01\u0e0a\u0e19\u0e17\u0e38\u0e01\u0e04\u0e19 \u0e2d\u0e32\u0e22\u0e38 15\u201360 \u0e1b\u0e35 \u0e23\u0e27\u0e21\u0e16\u0e36\u0e07\u0e0a\u0e32\u0e27\u0e15\u0e48\u0e32\u0e07\u0e0a\u0e32\u0e15\u0e34\u0e17\u0e35\u0e48\u0e21\u0e35\u0e43\u0e1a\u0e2d\u0e19\u0e38\u0e0d\u0e32\u0e15\u0e17\u0e33\u0e07\u0e32\u0e19',
rate_title:'\u0e2d\u0e31\u0e15\u0e23\u0e32\u0e2a\u0e21\u0e17\u0e1a',
rate_hdr:'<tr><th>\u0e1d\u0e48\u0e32\u0e22</th><th class="r">\u0e2d\u0e31\u0e15\u0e23\u0e32</th><th>\u0e2b\u0e21\u0e32\u0e22\u0e40\u0e2b\u0e15\u0e38</th></tr>',
rate_tbl:'<tr><td>\u0e25\u0e39\u0e01\u0e08\u0e49\u0e32\u0e07</td><td class="r" style="font-family:var(--mono)">5%</td><td>\u0e2b\u0e31\u0e01\u0e08\u0e32\u0e01\u0e40\u0e07\u0e34\u0e19\u0e40\u0e14\u0e37\u0e2d\u0e19\u0e17\u0e38\u0e01\u0e40\u0e14\u0e37\u0e2d\u0e19</td></tr><tr><td>\u0e19\u0e32\u0e22\u0e08\u0e49\u0e32\u0e07</td><td class="r" style="font-family:var(--mono)">5%</td><td>\u0e2a\u0e21\u0e17\u0e1a\u0e2a\u0e21\u0e17\u0e1a \u0e08\u0e48\u0e32\u0e22\u0e41\u0e22\u0e01\u0e15\u0e48\u0e32\u0e07\u0e2b\u0e32\u0e01</td></tr><tr><td>\u0e23\u0e31\u0e10\u0e1a\u0e32\u0e25</td><td class="r" style="font-family:var(--mono)">2.75%</td><td>\u0e23\u0e31\u0e10\u0e1a\u0e32\u0e25\u0e08\u0e48\u0e32\u0e22</td></tr>',
ceil_title:'\u0e40\u0e1e\u0e14\u0e32\u0e19\u0e04\u0e48\u0e32\u0e08\u0e49\u0e32\u0e07 (\u0e1b\u0e23\u0e31\u0e1a\u0e2b\u0e25\u0e32\u0e22\u0e23\u0e30\u0e22\u0e30)',
ceil_hdr:'<tr><th>\u0e23\u0e30\u0e22\u0e30</th><th>\u0e0a\u0e48\u0e27\u0e07\u0e40\u0e27\u0e25\u0e32</th><th class="r">\u0e40\u0e1e\u0e14\u0e32\u0e19\u0e04\u0e48\u0e32\u0e08\u0e49\u0e32\u0e07</th><th class="r">\u0e2a\u0e39\u0e07\u0e2a\u0e38\u0e14/\u0e1d\u0e48\u0e32\u0e22</th><th class="r">\u0e23\u0e27\u0e21\u0e2a\u0e39\u0e07\u0e2a\u0e38\u0e14</th></tr>',
ceil_note:'\u0e04\u0e48\u0e32\u0e08\u0e49\u0e32\u0e07\u0e02\u0e31\u0e49\u0e19\u0e15\u0e48\u0e33: \u0e3f1,650/\u0e40\u0e14\u0e37\u0e2d\u0e19 \u0e1b\u0e23\u0e30\u0e01\u0e32\u0e28\u0e23\u0e32\u0e0a\u0e01\u0e34\u0e08\u0e08\u0e32\u0e19\u0e38\u0e40\u0e1a\u0e01\u0e29\u0e32: 12 \u0e18.\u0e04. 2568',
calc_title:'\u0e2a\u0e39\u0e15\u0e23\u0e04\u0e33\u0e19\u0e27\u0e13',
calc_body:'<strong>\u0e10\u0e32\u0e19\u0e2a\u0e21\u0e17\u0e1a</strong> = min(\u0e40\u0e07\u0e34\u0e19\u0e40\u0e14\u0e37\u0e2d\u0e19, \u0e40\u0e1e\u0e14\u0e32\u0e19\u0e04\u0e48\u0e32\u0e08\u0e49\u0e32\u0e07)<br><strong>\u0e40\u0e07\u0e34\u0e19\u0e2a\u0e21\u0e17\u0e1a\u0e25\u0e39\u0e01\u0e08\u0e49\u0e32\u0e07</strong> = \u0e10\u0e32\u0e19\u0e2a\u0e21\u0e17\u0e1a \u00d7 5%<br><br><strong>\u0e15\u0e31\u0e27\u0e2d\u0e22\u0e48\u0e32\u0e07 (2569):</strong><br>\u0e40\u0e07\u0e34\u0e19\u0e40\u0e14\u0e37\u0e2d\u0e19 \u0e3f10,000 \u2192 \u0e2a\u0e21\u0e17\u0e1a = <strong>\u0e3f500</strong><br>\u0e40\u0e07\u0e34\u0e19\u0e40\u0e14\u0e37\u0e2d\u0e19 \u0e3f17,500 \u2192 \u0e2a\u0e21\u0e17\u0e1a = <strong>\u0e3f875</strong> (\u0e40\u0e15\u0e47\u0e21\u0e40\u0e1e\u0e14\u0e32\u0e19)<br>\u0e40\u0e07\u0e34\u0e19\u0e40\u0e14\u0e37\u0e2d\u0e19 \u0e3f62,566 \u2192 \u0e2a\u0e21\u0e17\u0e1a = <strong>\u0e3f875</strong> (\u0e16\u0e39\u0e01\u0e08\u0e33\u0e01\u0e31\u0e14)',
setup_title:'\u0e27\u0e34\u0e18\u0e35\u0e15\u0e31\u0e49\u0e07\u0e04\u0e48\u0e32\u0e43\u0e19\u0e41\u0e2d\u0e1b',
setup_body:'<ol style="padding-left:18px"><li>\u0e44\u0e1b\u0e17\u0e35\u0e48\u0e41\u0e17\u0e47\u0e1a <strong>Payroll</strong></li><li>\u0e23\u0e32\u0e22\u0e01\u0e32\u0e23\u0e23\u0e32\u0e22\u0e44\u0e14\u0e49: \u0e15\u0e34\u0e01\u0e40\u0e04\u0e23\u0e37\u0e48\u0e2d\u0e07\u0e2b\u0e21\u0e32\u0e22 <strong>SSO</strong></li><li>\u0e23\u0e32\u0e22\u0e01\u0e32\u0e23\u0e2b\u0e31\u0e01: \u0e40\u0e25\u0e37\u0e2d\u0e01 <strong>"% of SSO Base"</strong>, \u0e2d\u0e31\u0e15\u0e23\u0e32 = <strong>5%</strong>, \u0e40\u0e1e\u0e14\u0e32\u0e19 = <strong>\u0e3f875</strong></li></ol>',
benefit_title:'\u0e2a\u0e34\u0e17\u0e18\u0e34\u0e1b\u0e23\u0e30\u0e42\u0e22\u0e0a\u0e19\u0e4c (\u0e2d\u0e31\u0e15\u0e23\u0e32\u0e1b\u0e35 2569)',
benefit_hdr:'<tr><th>\u0e2a\u0e34\u0e17\u0e18\u0e34\u0e1b\u0e23\u0e30\u0e42\u0e22\u0e0a\u0e19\u0e4c</th><th class="r">\u0e01\u0e48\u0e2d\u0e19 2569</th><th class="r">\u0e15\u0e31\u0e49\u0e07\u0e41\u0e15\u0e48 \u0e21.\u0e04. 2569</th></tr>',
compliance_title:'\u0e02\u0e49\u0e2d\u0e1b\u0e0f\u0e34\u0e1a\u0e31\u0e15\u0e34\u0e2a\u0e33\u0e04\u0e31\u0e0d',
compliance:'<li>\u0e19\u0e33\u0e2a\u0e48\u0e07\u0e20\u0e32\u0e22\u0e43\u0e19<strong>\u0e27\u0e31\u0e19\u0e17\u0e35\u0e48 15 \u0e02\u0e2d\u0e07\u0e40\u0e14\u0e37\u0e2d\u0e19\u0e16\u0e31\u0e14\u0e44\u0e1b</strong></li><li>\u0e04\u0e48\u0e32\u0e1b\u0e23\u0e31\u0e1a\u0e25\u0e48\u0e32\u0e0a\u0e49\u0e32: <strong>2% \u0e15\u0e48\u0e2d\u0e40\u0e14\u0e37\u0e2d\u0e19</strong></li><li>\u0e02\u0e36\u0e49\u0e19\u0e17\u0e30\u0e40\u0e1a\u0e35\u0e22\u0e19\u0e20\u0e32\u0e22\u0e43\u0e19 <strong>30 \u0e27\u0e31\u0e19</strong></li><li>\u0e04\u0e38\u0e49\u0e21\u0e04\u0e23\u0e2d\u0e07\u0e40\u0e23\u0e34\u0e48\u0e21<strong>\u0e15\u0e31\u0e49\u0e07\u0e41\u0e15\u0e48\u0e27\u0e31\u0e19\u0e41\u0e23\u0e01\u0e17\u0e35\u0e48\u0e17\u0e33\u0e07\u0e32\u0e19</strong></li>',
sources_title:'\u0e41\u0e2b\u0e25\u0e48\u0e07\u0e02\u0e49\u0e2d\u0e21\u0e39\u0e25',
tax_title:'\u0e20\u0e32\u0e29\u0e35\u0e40\u0e07\u0e34\u0e19\u0e44\u0e14\u0e49\u0e1a\u0e38\u0e04\u0e04\u0e25\u0e18\u0e23\u0e23\u0e21\u0e14\u0e32',
tax_rates:'<table class="tbl" style="margin-bottom:10px"><thead><tr><th>\u0e40\u0e07\u0e34\u0e19\u0e44\u0e14\u0e49\u0e2a\u0e38\u0e17\u0e18\u0e34 (\u0e1a\u0e32\u0e17)</th><th class="r">\u0e2d\u0e31\u0e15\u0e23\u0e32</th><th class="r">\u0e20\u0e32\u0e29\u0e35\u0e2a\u0e39\u0e07\u0e2a\u0e38\u0e14</th></tr></thead><tbody>'+
'<tr><td>0 - 150,000</td><td class="r">\u0e22\u0e01\u0e40\u0e27\u0e49\u0e19</td><td class="r">0</td></tr>'+
'<tr><td>150,001 - 300,000</td><td class="r">5%</td><td class="r">7,500</td></tr>'+
'<tr><td>300,001 - 500,000</td><td class="r">10%</td><td class="r">20,000</td></tr>'+
'<tr><td>500,001 - 750,000</td><td class="r">15%</td><td class="r">37,500</td></tr>'+
'<tr><td>750,001 - 1,000,000</td><td class="r">20%</td><td class="r">50,000</td></tr>'+
'<tr><td>1,000,001 - 2,000,000</td><td class="r">25%</td><td class="r">250,000</td></tr>'+
'<tr><td>2,000,001 - 5,000,000</td><td class="r">30%</td><td class="r">900,000</td></tr>'+
'<tr><td>5,000,001+</td><td class="r">35%</td><td class="r">-</td></tr></tbody></table>',
tax_formula:'<strong>\u0e40\u0e07\u0e34\u0e19\u0e44\u0e14\u0e49\u0e2a\u0e38\u0e17\u0e18\u0e34</strong> = \u0e40\u0e07\u0e34\u0e19\u0e44\u0e14\u0e49\u0e1e\u0e36\u0e07\u0e1b\u0e23\u0e30\u0e40\u0e21\u0e34\u0e19 - \u0e04\u0e48\u0e32\u0e43\u0e0a\u0e49\u0e08\u0e48\u0e32\u0e22 (50% \u0e2a\u0e39\u0e07\u0e2a\u0e38\u0e14 \u0e3f100,000) - \u0e04\u0e48\u0e32\u0e25\u0e14\u0e2b\u0e22\u0e48\u0e2d\u0e19<br><strong>\u0e20\u0e32\u0e29\u0e35</strong> = \u0e04\u0e33\u0e19\u0e27\u0e13\u0e15\u0e32\u0e21\u0e2d\u0e31\u0e15\u0e23\u0e32\u0e01\u0e49\u0e32\u0e27\u0e2b\u0e19\u0e49\u0e32',
tax_exemptions_title:'\u0e23\u0e32\u0e22\u0e01\u0e32\u0e23\u0e25\u0e14\u0e2b\u0e22\u0e48\u0e2d\u0e19\u0e41\u0e25\u0e30\u0e22\u0e01\u0e40\u0e27\u0e49\u0e19\u0e20\u0e32\u0e29\u0e35',
tax_exemptions_detail:'<table class="tbl" style="margin-bottom:10px;font-size:10px"><thead><tr><th>\u0e23\u0e32\u0e22\u0e01\u0e32\u0e23\u0e25\u0e14\u0e2b\u0e22\u0e48\u0e2d\u0e19</th><th class="r">\u0e2a\u0e39\u0e07\u0e2a\u0e38\u0e14 (\u0e3f)</th><th>\u0e23\u0e32\u0e22\u0e25\u0e30\u0e40\u0e2d\u0e35\u0e22\u0e14\u0e41\u0e25\u0e30\u0e40\u0e07\u0e37\u0e48\u0e2d\u0e19\u0e44\u0e02</th></tr></thead><tbody>'+
'<tr><td><strong>\u0e04\u0e48\u0e32\u0e25\u0e14\u0e2b\u0e22\u0e48\u0e2d\u0e19\u0e2a\u0e48\u0e27\u0e19\u0e15\u0e31\u0e27</strong></td><td class="r">60,000</td><td>\u0e1c\u0e39\u0e49\u0e40\u0e2a\u0e35\u0e22\u0e20\u0e32\u0e29\u0e35\u0e17\u0e38\u0e01\u0e04\u0e19 \u0e44\u0e21\u0e48\u0e21\u0e35\u0e40\u0e07\u0e37\u0e48\u0e2d\u0e19\u0e44\u0e02</td></tr>'+
'<tr><td><strong>\u0e04\u0e48\u0e32\u0e25\u0e14\u0e2b\u0e22\u0e48\u0e2d\u0e19\u0e04\u0e39\u0e48\u0e2a\u0e21\u0e23\u0e2a</strong></td><td class="r">60,000</td><td>\u0e04\u0e39\u0e48\u0e2a\u0e21\u0e23\u0e2a\u0e44\u0e21\u0e48\u0e21\u0e35\u0e40\u0e07\u0e34\u0e19\u0e44\u0e14\u0e49 \u0e2b\u0e23\u0e37\u0e2d\u0e22\u0e37\u0e48\u0e19\u0e20\u0e32\u0e29\u0e35\u0e23\u0e48\u0e27\u0e21\u0e01\u0e31\u0e19</td></tr>'+
'<tr><td><strong>\u0e04\u0e48\u0e32\u0e25\u0e14\u0e2b\u0e22\u0e48\u0e2d\u0e19\u0e1a\u0e38\u0e15\u0e23</strong></td><td class="r">30,000/\u0e04\u0e19</td><td>\u0e1a\u0e38\u0e15\u0e23\u0e0a\u0e2d\u0e1a\u0e14\u0e49\u0e27\u0e22\u0e01\u0e0e\u0e2b\u0e21\u0e32\u0e22 \u0e1a\u0e38\u0e15\u0e23\u0e04\u0e19\u0e17\u0e35\u0e48 2 \u0e40\u0e01\u0e34\u0e14\u0e1b\u0e35 2561+ \u0e44\u0e14\u0e49 \u0e3f60,000</td></tr>'+
'<tr><td><strong>\u0e40\u0e25\u0e35\u0e49\u0e22\u0e07\u0e14\u0e39\u0e1a\u0e34\u0e14\u0e32\u0e21\u0e32\u0e23\u0e14\u0e32</strong></td><td class="r">30,000/\u0e04\u0e19</td><td>\u0e1a\u0e34\u0e14\u0e32\u0e21\u0e32\u0e23\u0e14\u0e32\u0e2d\u0e32\u0e22\u0e38 60+ \u0e21\u0e35\u0e23\u0e32\u0e22\u0e44\u0e14\u0e49\u0e44\u0e21\u0e48\u0e40\u0e01\u0e34\u0e19 \u0e3f30,000/\u0e1b\u0e35 \u0e2a\u0e39\u0e07\u0e2a\u0e38\u0e14 4 \u0e04\u0e19</td></tr>'+
'<tr><td><strong>\u0e40\u0e25\u0e35\u0e49\u0e22\u0e07\u0e14\u0e39\u0e04\u0e19\u0e1e\u0e34\u0e01\u0e32\u0e23</strong></td><td class="r">60,000</td><td>\u0e14\u0e39\u0e41\u0e25\u0e2a\u0e21\u0e32\u0e0a\u0e34\u0e01\u0e04\u0e23\u0e2d\u0e1a\u0e04\u0e23\u0e31\u0e27\u0e1c\u0e39\u0e49\u0e1e\u0e34\u0e01\u0e32\u0e23</td></tr>'+
'<tr style="background:var(--bg3)"><td colspan="3"><strong>\u2014 \u0e04\u0e48\u0e32\u0e43\u0e0a\u0e49\u0e08\u0e48\u0e32\u0e22\u0e40\u0e1e\u0e37\u0e48\u0e2d\u0e01\u0e32\u0e23\u0e17\u0e33\u0e07\u0e32\u0e19 \u2014</strong></td></tr>'+
'<tr><td><strong>\u0e2b\u0e31\u0e01\u0e04\u0e48\u0e32\u0e43\u0e0a\u0e49\u0e08\u0e48\u0e32\u0e22</strong></td><td class="r">100,000</td><td>50% \u0e02\u0e2d\u0e07\u0e40\u0e07\u0e34\u0e19\u0e44\u0e14\u0e49\u0e08\u0e32\u0e01\u0e01\u0e32\u0e23\u0e08\u0e49\u0e32\u0e07\u0e07\u0e32\u0e19 \u0e2a\u0e39\u0e07\u0e2a\u0e38\u0e14 \u0e3f100,000 \u0e04\u0e33\u0e19\u0e27\u0e13\u0e2d\u0e31\u0e15\u0e42\u0e19\u0e21\u0e31\u0e15\u0e34</td></tr>'+
'<tr style="background:var(--bg3)"><td colspan="3"><strong>\u2014 \u0e1b\u0e23\u0e30\u0e01\u0e31\u0e19 & \u0e2d\u0e2d\u0e21\u0e17\u0e23\u0e31\u0e1e\u0e22\u0e4c \u2014</strong></td></tr>'+
'<tr><td><strong>\u0e40\u0e1a\u0e35\u0e49\u0e22\u0e1b\u0e23\u0e30\u0e01\u0e31\u0e19\u0e0a\u0e35\u0e27\u0e34\u0e15</strong></td><td class="r">100,000</td><td>\u0e01\u0e23\u0e21\u0e18\u0e23\u0e23\u0e21\u0e4c 10 \u0e1b\u0e35\u0e02\u0e36\u0e49\u0e19\u0e44\u0e1b \u0e01\u0e31\u0e1a\u0e1a\u0e23\u0e34\u0e29\u0e31\u0e17\u0e1b\u0e23\u0e30\u0e01\u0e31\u0e19\u0e43\u0e19\u0e44\u0e17\u0e22 \u0e23\u0e27\u0e21\u0e1b\u0e23\u0e30\u0e01\u0e31\u0e19\u0e2a\u0e38\u0e02\u0e20\u0e32\u0e1e\u0e44\u0e21\u0e48\u0e40\u0e01\u0e34\u0e19 \u0e3f100,000</td></tr>'+
'<tr><td><strong>\u0e1b\u0e23\u0e30\u0e01\u0e31\u0e19\u0e2a\u0e38\u0e02\u0e20\u0e32\u0e1e</strong></td><td class="r">25,000</td><td>\u0e02\u0e2d\u0e07\u0e15\u0e19\u0e40\u0e2d\u0e07 \u0e23\u0e27\u0e21\u0e01\u0e31\u0e1a\u0e1b\u0e23\u0e30\u0e01\u0e31\u0e19\u0e0a\u0e35\u0e27\u0e34\u0e15\u0e44\u0e21\u0e48\u0e40\u0e01\u0e34\u0e19 \u0e3f100,000</td></tr>'+
'<tr><td><strong>\u0e1b\u0e23\u0e30\u0e01\u0e31\u0e19\u0e2a\u0e31\u0e07\u0e04\u0e21 (\u0e2a\u0e1b\u0e2a.)</strong></td><td class="r">10,500</td><td>\u0e21.33: 5% \u0e02\u0e2d\u0e07\u0e04\u0e48\u0e32\u0e08\u0e49\u0e32\u0e07 \u0e40\u0e1e\u0e14\u0e32\u0e19 \u0e3f17,500 (2569-2571) \u0e2a\u0e39\u0e07\u0e2a\u0e38\u0e14 \u0e3f875/\u0e40\u0e14\u0e37\u0e2d\u0e19</td></tr>'+
'<tr><td><strong>\u0e01\u0e2d\u0e07\u0e17\u0e38\u0e19\u0e2a\u0e33\u0e23\u0e2d\u0e07\u0e40\u0e25\u0e35\u0e49\u0e22\u0e07\u0e0a\u0e35\u0e1e (PVD)</strong></td><td class="r">500,000</td><td>\u0e2a\u0e48\u0e27\u0e19\u0e17\u0e35\u0e48\u0e40\u0e01\u0e34\u0e19 \u0e3f10,000 \u0e25\u0e14\u0e2b\u0e22\u0e48\u0e2d\u0e19\u0e44\u0e14\u0e49\u0e16\u0e36\u0e07 \u0e3f490,000 \u0e2a\u0e39\u0e07\u0e2a\u0e38\u0e14 15% \u0e02\u0e2d\u0e07\u0e40\u0e07\u0e34\u0e19\u0e40\u0e14\u0e37\u0e2d\u0e19</td></tr>'+
'<tr style="background:var(--bg3)"><td colspan="3"><strong>\u2014 \u0e01\u0e2d\u0e07\u0e17\u0e38\u0e19\u0e23\u0e27\u0e21 (\u0e23\u0e27\u0e21\u0e01\u0e31\u0e19\u0e44\u0e21\u0e48\u0e40\u0e01\u0e34\u0e19 \u0e3f500,000) \u2014</strong></td></tr>'+
'<tr><td><strong>RMF (\u0e01\u0e2d\u0e07\u0e17\u0e38\u0e19\u0e23\u0e27\u0e21\u0e40\u0e1e\u0e37\u0e48\u0e2d\u0e01\u0e32\u0e23\u0e40\u0e25\u0e35\u0e49\u0e22\u0e07\u0e0a\u0e35\u0e1e)</strong></td><td class="r">500,000</td><td>\u0e2a\u0e39\u0e07\u0e2a\u0e38\u0e14 30% \u0e02\u0e2d\u0e07\u0e40\u0e07\u0e34\u0e19\u0e44\u0e14\u0e49 \u0e15\u0e49\u0e2d\u0e07\u0e25\u0e07\u0e17\u0e38\u0e19\u0e15\u0e48\u0e2d\u0e40\u0e19\u0e37\u0e48\u0e2d\u0e07\u0e16\u0e36\u0e07\u0e2d\u0e32\u0e22\u0e38 55</td></tr>'+
'<tr><td><strong>SSF (\u0e01\u0e2d\u0e07\u0e17\u0e38\u0e19\u0e23\u0e27\u0e21\u0e40\u0e1e\u0e37\u0e48\u0e2d\u0e01\u0e32\u0e23\u0e2d\u0e2d\u0e21)</strong></td><td class="r">200,000</td><td>\u0e2a\u0e39\u0e07\u0e2a\u0e38\u0e14 30% \u0e02\u0e2d\u0e07\u0e40\u0e07\u0e34\u0e19\u0e44\u0e14\u0e49 \u0e16\u0e37\u0e2d\u0e04\u0e23\u0e2d\u0e07\u0e02\u0e31\u0e49\u0e19\u0e15\u0e48\u0e33 10 \u0e1b\u0e35</td></tr>'+
'<tr><td><strong>Thai ESG</strong></td><td class="r">300,000</td><td>\u0e2a\u0e39\u0e07\u0e2a\u0e38\u0e14 30% \u0e02\u0e2d\u0e07\u0e40\u0e07\u0e34\u0e19\u0e44\u0e14\u0e49 \u0e16\u0e37\u0e2d\u0e04\u0e23\u0e2d\u0e07\u0e02\u0e31\u0e49\u0e19\u0e15\u0e48\u0e33 8 \u0e1b\u0e35 (2567-2569)</td></tr>'+
'<tr style="background:var(--bg3)"><td colspan="3"><strong>\u2014 \u0e17\u0e23\u0e31\u0e1e\u0e22\u0e4c\u0e2a\u0e34\u0e19 & \u0e40\u0e07\u0e34\u0e19\u0e1a\u0e23\u0e34\u0e08\u0e32\u0e04 \u2014</strong></td></tr>'+
'<tr><td><strong>\u0e14\u0e2d\u0e01\u0e40\u0e1a\u0e35\u0e49\u0e22\u0e40\u0e07\u0e34\u0e19\u0e01\u0e39\u0e49\u0e17\u0e35\u0e48\u0e2d\u0e22\u0e39\u0e48\u0e2d\u0e32\u0e28\u0e31\u0e22</strong></td><td class="r">100,000</td><td>\u0e14\u0e2d\u0e01\u0e40\u0e1a\u0e35\u0e49\u0e22\u0e08\u0e32\u0e01\u0e2a\u0e34\u0e19\u0e40\u0e0a\u0e37\u0e48\u0e2d\u0e17\u0e35\u0e48\u0e2d\u0e22\u0e39\u0e48\u0e2d\u0e32\u0e28\u0e31\u0e22\u0e17\u0e35\u0e48\u0e43\u0e0a\u0e49\u0e2d\u0e22\u0e39\u0e48\u0e08\u0e23\u0e34\u0e07 \u0e1c\u0e39\u0e49\u0e43\u0e2b\u0e49\u0e01\u0e39\u0e49\u0e15\u0e49\u0e2d\u0e07\u0e40\u0e1b\u0e47\u0e19\u0e2a\u0e16\u0e32\u0e1a\u0e31\u0e19\u0e01\u0e32\u0e23\u0e40\u0e07\u0e34\u0e19\u0e43\u0e19\u0e44\u0e17\u0e22 <strong>\u0e01\u0e23\u0e13\u0e35\u0e01\u0e39\u0e49\u0e23\u0e48\u0e27\u0e21:</strong> \u0e27\u0e07\u0e40\u0e07\u0e34\u0e19 \u0e3f100,000 \u0e2b\u0e32\u0e23\u0e40\u0e17\u0e48\u0e32\u0e46 \u0e01\u0e31\u0e19\u0e15\u0e32\u0e21\u0e08\u0e33\u0e19\u0e27\u0e19\u0e1c\u0e39\u0e49\u0e01\u0e39\u0e49 \u0e40\u0e0a\u0e48\u0e19 \u0e01\u0e39\u0e49\u0e23\u0e48\u0e27\u0e21 2 \u0e04\u0e19 = \u0e04\u0e19\u0e25\u0e30 \u0e3f50,000, \u0e01\u0e39\u0e49\u0e23\u0e48\u0e27\u0e21 3 \u0e04\u0e19 = \u0e04\u0e19\u0e25\u0e30 \u0e3f33,333 \u0e01\u0e39\u0e49\u0e2b\u0e25\u0e32\u0e22\u0e2b\u0e25\u0e31\u0e07\u0e44\u0e14\u0e49\u0e41\u0e15\u0e48\u0e23\u0e27\u0e21\u0e01\u0e31\u0e19\u0e44\u0e21\u0e48\u0e40\u0e01\u0e34\u0e19 \u0e3f100,000 \u0e15\u0e48\u0e2d\u0e04\u0e19</td></tr>'+
'<tr><td><strong>\u0e40\u0e07\u0e34\u0e19\u0e1a\u0e23\u0e34\u0e08\u0e32\u0e04\u0e17\u0e31\u0e48\u0e27\u0e44\u0e1b</strong></td><td class="r">10% \u0e02\u0e2d\u0e07\u0e40\u0e07\u0e34\u0e19\u0e44\u0e14\u0e49\u0e2a\u0e38\u0e17\u0e18\u0e34</td><td>\u0e1a\u0e23\u0e34\u0e08\u0e32\u0e04\u0e41\u0e01\u0e48\u0e2d\u0e07\u0e04\u0e4c\u0e01\u0e23\u0e2a\u0e32\u0e18\u0e32\u0e23\u0e13\u0e01\u0e38\u0e28\u0e25\u0e17\u0e35\u0e48\u0e44\u0e14\u0e49\u0e23\u0e31\u0e1a\u0e2d\u0e19\u0e38\u0e21\u0e31\u0e15\u0e34</td></tr>'+
'<tr><td><strong>\u0e1a\u0e23\u0e34\u0e08\u0e32\u0e04\u0e01\u0e32\u0e23\u0e28\u0e36\u0e01\u0e29\u0e32/\u0e01\u0e35\u0e2c\u0e32</strong></td><td class="r">2x \u0e2a\u0e39\u0e07\u0e2a\u0e38\u0e14 10%</td><td>\u0e2b\u0e31\u0e01\u0e44\u0e14\u0e49 2 \u0e40\u0e17\u0e48\u0e32 \u0e2a\u0e39\u0e07\u0e2a\u0e38\u0e14 10% \u0e02\u0e2d\u0e07\u0e40\u0e07\u0e34\u0e19\u0e44\u0e14\u0e49\u0e2a\u0e38\u0e17\u0e18\u0e34</td></tr>'+
'</tbody></table>'+
'<div style="font-size:9px;color:var(--text3);margin-top:6px">\u0e2b\u0e21\u0e32\u0e22\u0e40\u0e2b\u0e15\u0e38: RMF + SSF + Thai ESG + PVD \u0e23\u0e27\u0e21\u0e01\u0e31\u0e19\u0e44\u0e21\u0e48\u0e40\u0e01\u0e34\u0e19 \u0e3f500,000 \u0e1b\u0e23\u0e30\u0e01\u0e31\u0e19\u0e0a\u0e35\u0e27\u0e34\u0e15 + \u0e1b\u0e23\u0e30\u0e01\u0e31\u0e19\u0e2a\u0e38\u0e02\u0e20\u0e32\u0e1e \u0e23\u0e27\u0e21\u0e01\u0e31\u0e19\u0e44\u0e21\u0e48\u0e40\u0e01\u0e34\u0e19 \u0e3f100,000 \u0e08\u0e33\u0e19\u0e27\u0e19\u0e41\u0e25\u0e30\u0e40\u0e07\u0e37\u0e48\u0e2d\u0e19\u0e44\u0e02\u0e2d\u0e49\u0e32\u0e07\u0e2d\u0e34\u0e07\u0e1b\u0e23\u0e30\u0e21\u0e27\u0e25\u0e23\u0e31\u0e29\u0e0e\u0e32\u0e01\u0e23\u0e41\u0e25\u0e30\u0e23\u0e30\u0e40\u0e1a\u0e35\u0e22\u0e1a\u0e1b\u0e35 2569 \u0e04\u0e27\u0e23\u0e15\u0e23\u0e27\u0e08\u0e2a\u0e2d\u0e1a\u0e01\u0e31\u0e1a\u0e01\u0e23\u0e21\u0e2a\u0e23\u0e23\u0e1e\u0e32\u0e01\u0e23\u0e2b\u0e23\u0e37\u0e2d\u0e17\u0e35\u0e48\u0e1b\u0e23\u0e36\u0e01\u0e29\u0e32\u0e20\u0e32\u0e29\u0e35</div>'
},
ja:{
title:'\u30d8\u30eb\u30d7\u30fb\u30ea\u30d5\u30a1\u30ec\u30f3\u30b9',
sso_title:'\u30bf\u30a4\u793e\u4f1a\u4fdd\u969c (SSO) \u2014 \u62e0\u51fa\u91d1\u30eb\u30fc\u30eb',
legal:'<strong>\u6cd5\u7684\u6839\u62e0:</strong> \u793e\u4f1a\u4fdd\u969c\u6cd5 B.E.2533 (1990\u5e74) \u7b2c33\u6761<br><strong>\u7ba1\u8f44\u6a5f\u95a2:</strong> \u793e\u4f1a\u4fdd\u969c\u4e8b\u52d9\u5c40 (SSO)\u3001\u52b4\u50cd\u7701<br><strong>\u5bfe\u8c61\u8005:</strong> 15\u301c60\u6b73\u306e\u5168\u6c11\u9593\u90e8\u9580\u5f93\u696d\u54e1\uff08\u5916\u56fd\u4eba\u52b4\u50cd\u8a31\u53ef\u4fdd\u6709\u8005\u3092\u542b\u3080\uff09',
rate_title:'\u62e0\u51fa\u7387',
rate_hdr:'<tr><th>\u5f53\u4e8b\u8005</th><th class="r">\u7387</th><th>\u5099\u8003</th></tr>',
rate_tbl:'<tr><td>\u5f93\u696d\u54e1</td><td class="r" style="font-family:var(--mono)">5%</td><td>\u6bce\u6708\u7d66\u4e0e\u304b\u3089\u63a7\u9664</td></tr><tr><td>\u96c7\u7528\u4e3b</td><td class="r" style="font-family:var(--mono)">5%</td><td>\u30de\u30c3\u30c1\u30f3\u30b0\u62e0\u51fa\u3001\u5225\u9014\u652f\u6255\u3044</td></tr><tr><td>\u653f\u5e9c</td><td class="r" style="font-family:var(--mono)">2.75%</td><td>\u56fd\u304c\u8ca0\u62c5</td></tr>',
ceil_title:'\u8cc3\u91d1\u4e0a\u9650\u984d\uff08\u6bb5\u968e\u7684\u6539\u9769\uff09',
ceil_hdr:'<tr><th>\u30d5\u30a7\u30fc\u30ba</th><th>\u671f\u9593</th><th class="r">\u8cc3\u91d1\u4e0a\u9650</th><th class="r">\u6700\u5927/\u5f53\u4e8b\u8005</th><th class="r">\u5408\u8a08\u6700\u5927</th></tr>',
ceil_note:'\u6700\u4f4e\u8cc3\u91d1: \u0e3f1,650/\u6708\u3002\u5b98\u5831\u516c\u5e03: 2025\u5e7412\u670812\u65e5\u3002',
calc_title:'\u8a08\u7b97\u5f0f',
calc_body:'<strong>\u62e0\u51fa\u30d9\u30fc\u30b9</strong> = min(\u6708\u7d66, \u8cc3\u91d1\u4e0a\u9650)<br><strong>\u5f93\u696d\u54e1SSO</strong> = \u62e0\u51fa\u30d9\u30fc\u30b9 \u00d7 5%<br><br><strong>\u4f8b (2026\u5e74):</strong><br>\u6708\u7d66 \u0e3f10,000 \u2192 <strong>\u0e3f500</strong><br>\u6708\u7d66 \u0e3f17,500 \u2192 <strong>\u0e3f875</strong> (\u4e0a\u9650)<br>\u6708\u7d66 \u0e3f62,566 \u2192 <strong>\u0e3f875</strong> (\u4e0a\u9650\u9069\u7528)',
setup_title:'\u30a2\u30d7\u30ea\u3067\u306e\u8a2d\u5b9a\u65b9\u6cd5',
setup_body:'<ol style="padding-left:18px"><li><strong>Payroll</strong>\u30bf\u30d6\u3078</li><li>\u53ce\u5165\u9805\u76ee: <strong>SSO</strong>\u30c1\u30a7\u30c3\u30af\u30dc\u30c3\u30af\u30b9\u3092\u30aa\u30f3</li><li>\u63a7\u9664\u9805\u76ee: <strong>"% of SSO Base"</strong>\u3001\u7387 = <strong>5%</strong>\u3001\u4e0a\u9650 = <strong>\u0e3f875</strong></li></ol>',
benefit_title:'SSO\u7d66\u4ed8\u91d1 (2026\u5e74\u7387)',
benefit_hdr:'<tr><th>\u7d66\u4ed8</th><th class="r">2026\u5e74\u524d</th><th class="r">2026\u5e741\u6708\u304b\u3089</th></tr>',
compliance_title:'\u4e3b\u306a\u30b3\u30f3\u30d7\u30e9\u30a4\u30a2\u30f3\u30b9\u4e8b\u9805',
compliance:'<li>\u7d0d\u4ed8\u671f\u9650: <strong>\u7fcc\u670815\u65e5</strong></li><li>\u5ef6\u6ede\u7f70\u5247: <strong>\u6708\u30012%</strong></li><li>\u767b\u9332\u671f\u9650: <strong>\u5165\u793e\u304b\u308930\u65e5\u4ee5\u5185</strong></li><li>\u88dc\u511f\u958b\u59cb: <strong>\u521d\u65e5\u304b\u3089</strong></li>',
sources_title:'\u51fa\u5178',
tax_title:'\u30bf\u30a4\u500b\u4eba\u6240\u5f97\u7a0e',
tax_rates:'<table class="tbl" style="margin-bottom:10px"><thead><tr><th>\u8ab2\u7a0e\u6240\u5f97\uff08\u30d0\u30fc\u30c4\uff09</th><th class="r">\u7a0e\u7387</th><th class="r">\u6700\u5927\u7a0e\u984d</th></tr></thead><tbody>'+
'<tr><td>0 - 150,000</td><td class="r">\u514d\u7a0e</td><td class="r">0</td></tr>'+
'<tr><td>150,001 - 300,000</td><td class="r">5%</td><td class="r">7,500</td></tr>'+
'<tr><td>300,001 - 500,000</td><td class="r">10%</td><td class="r">20,000</td></tr>'+
'<tr><td>500,001 - 750,000</td><td class="r">15%</td><td class="r">37,500</td></tr>'+
'<tr><td>750,001 - 1,000,000</td><td class="r">20%</td><td class="r">50,000</td></tr>'+
'<tr><td>1,000,001 - 2,000,000</td><td class="r">25%</td><td class="r">250,000</td></tr>'+
'<tr><td>2,000,001 - 5,000,000</td><td class="r">30%</td><td class="r">900,000</td></tr>'+
'<tr><td>5,000,001+</td><td class="r">35%</td><td class="r">-</td></tr></tbody></table>',
tax_formula:'<strong>\u8ab2\u7a0e\u6240\u5f97</strong> = \u8a55\u4fa1\u6240\u5f97 - \u7d4c\u8cbb\u63a7\u9664\uff0850%\u3001\u4e0a\u9650 \u0e3f100,000\uff09 - \u6240\u5f97\u63a7\u9664<br><strong>\u7a0e\u984d</strong> = \u7d2f\u9032\u7a0e\u7387\u3092\u8ab2\u7a0e\u6240\u5f97\u306b\u9069\u7528',
tax_exemptions_title:'\u6240\u5f97\u63a7\u9664\u30fb\u7a0e\u984d\u63a7\u9664\u4e00\u89a7',
tax_exemptions_detail:'<table class="tbl" style="margin-bottom:10px;font-size:10px"><thead><tr><th>\u63a7\u9664\u9805\u76ee</th><th class="r">\u4e0a\u9650\u984d\uff08\u0e3f\uff09</th><th>\u8a73\u7d30\u30fb\u6761\u4ef6</th></tr></thead><tbody>'+
'<tr><td><strong>\u57fa\u790e\u63a7\u9664</strong></td><td class="r">60,000</td><td>\u5168\u7d0d\u7a0e\u8005\u3002\u6761\u4ef6\u306a\u3057\u3002</td></tr>'+
'<tr><td><strong>\u914d\u5076\u8005\u63a7\u9664</strong></td><td class="r">60,000</td><td>\u914d\u5076\u8005\u306b\u6240\u5f97\u304c\u306a\u3044\u5834\u5408\u3001\u307e\u305f\u306f\u5408\u7b97\u7533\u544a\u306e\u5834\u5408\u3002</td></tr>'+
'<tr><td><strong>\u5b50\u5973\u63a7\u9664</strong></td><td class="r">30,000/\u4eba</td><td>\u5ae1\u51fa\u5b50\u30022018\u5e74\u4ee5\u964d\u306e\u7b2c2\u5b50\u306f\u0e3f60,000\u3002</td></tr>'+
'<tr><td><strong>\u89aa\u6276\u990a\u63a7\u9664</strong></td><td class="r">30,000/\u4eba</td><td>60\u6b73\u4ee5\u4e0a\u3067\u6240\u5f97\u0e3f30,000/\u5e74\u4ee5\u4e0b\u3002\u6700\u59274\u540d\u3002</td></tr>'+
'<tr><td><strong>\u969c\u5bb3\u8005\u6276\u990a\u63a7\u9664</strong></td><td class="r">60,000</td><td>\u969c\u5bb3\u306e\u3042\u308b\u5bb6\u65cf\u306e\u4ecb\u8b77\u3002</td></tr>'+
'<tr style="background:var(--bg3)"><td colspan="3"><strong>\u2014 \u5c31\u696d\u7d4c\u8cbb\u63a7\u9664 \u2014</strong></td></tr>'+
'<tr><td><strong>\u7d4c\u8cbb\u63a7\u9664</strong></td><td class="r">100,000</td><td>\u7d66\u4e0e\u6240\u5f97\u306e50%\u3001\u4e0a\u9650\u0e3f100,000\u3002\u81ea\u52d5\u8a08\u7b97\u3002</td></tr>'+
'<tr style="background:var(--bg3)"><td colspan="3"><strong>\u2014 \u4fdd\u967a\u30fb\u8caf\u84c4 \u2014</strong></td></tr>'+
'<tr><td><strong>\u751f\u547d\u4fdd\u967a\u6599</strong></td><td class="r">100,000</td><td>\u30bf\u30a4\u8a8d\u53ef\u4fdd\u967a\u4f1a\u793e\u3002\u5951\u7d0410\u5e74\u4ee5\u4e0a\u3002\u5065\u5eb7\u4fdd\u967a\u3068\u5408\u8a08\u0e3f100,000\u307e\u3067\u3002</td></tr>'+
'<tr><td><strong>\u5065\u5eb7\u4fdd\u967a\u6599</strong></td><td class="r">25,000</td><td>\u672c\u4eba\u306e\u307f\u3002\u751f\u547d\u4fdd\u967a\u3068\u5408\u8a08\u0e3f100,000\u3092\u8d85\u3048\u306a\u3044\u3002</td></tr>'+
'<tr><td><strong>\u793e\u4f1a\u4fdd\u967a\uff08SSO\uff09</strong></td><td class="r">10,500</td><td>\u7b2c33\u6761\uff1a\u8cc3\u91d1\u306e5%\u3001\u4e0a\u9650\u0e3f17,500\uff082026-2028\u5e74\uff09\u3002\u6708\u984d\u4e0a\u9650\u0e3f875\u3002</td></tr>'+
'<tr><td><strong>\u9000\u8077\u7a4d\u7acb\u57fa\u91d1\uff08PVD\uff09</strong></td><td class="r">500,000</td><td>\u0e3f10,000\u8d85\u904e\u5206\u304c\u6700\u5927\u0e3f490,000\u307e\u3067\u63a7\u9664\u53ef\u3002\u7d66\u4e0e\u306e15%\u307e\u3067\u3002</td></tr>'+
'<tr style="background:var(--bg3)"><td colspan="3"><strong>\u2014 \u6295\u8cc7\u30d5\u30a1\u30f3\u30c9\uff08\u5408\u8a08\u4e0a\u9650\u0e3f500,000\uff09 \u2014</strong></td></tr>'+
'<tr><td><strong>RMF\uff08\u9000\u8077\u6295\u8cc7\u4fe1\u8a17\uff09</strong></td><td class="r">500,000</td><td>\u6240\u5f97\u306e30%\u307e\u3067\u300255\u6b73\u307e\u3067\u7d99\u7d9a\u6295\u8cc7\u5fc5\u9808\u3002</td></tr>'+
'<tr><td><strong>SSF\uff08\u8caf\u84c4\u6295\u8cc7\u4fe1\u8a17\uff09</strong></td><td class="r">200,000</td><td>\u6240\u5f97\u306e30%\u307e\u3067\u3002\u6700\u4f4e\u4fdd\u6709\u671f\u959310\u5e74\u3002</td></tr>'+
'<tr><td><strong>Thai ESG</strong></td><td class="r">300,000</td><td>\u6240\u5f97\u306e30%\u307e\u3067\u3002\u6700\u4f4e\u4fdd\u6709\u671f\u95938\u5e74\uff082024-2026\u5e74\uff09\u3002</td></tr>'+
'<tr style="background:var(--bg3)"><td colspan="3"><strong>\u2014 \u4e0d\u52d5\u7523\u30fb\u5bc4\u4ed8\u91d1 \u2014</strong></td></tr>'+
'<tr><td><strong>\u4f4f\u5b85\u30ed\u30fc\u30f3\u5229\u606f</strong></td><td class="r">100,000</td><td>\u81ea\u5df1\u5c45\u4f4f\u7528\u4f4f\u5b85\u306e\u4f4f\u5b85\u30ed\u30fc\u30f3\u5229\u606f\u3002\u30bf\u30a4\u306e\u91d1\u878d\u6a5f\u95a2\u304b\u3089\u306e\u501f\u5165\u304c\u5bfe\u8c61\u3002<strong>\u5171\u540c\u501f\u5165\u306e\u5834\u5408\uff1a</strong>\u0e3f100,000\u306e\u4e0a\u9650\u3092\u501f\u5165\u4eba\u6570\u3067\u5747\u7b49\u5206\u5272 \u2014 \u4f8b\uff1a2\u540d\u3067\u5171\u540c\u501f\u5165=\u5404\u0e3f50,000\u30013\u540d=\u5404\u0e3f33,333\u3002\u8907\u6570\u7269\u4ef6\u306e\u5408\u7b97\u30821\u4eba\u3042\u305f\u308a\u4e0a\u9650\u0e3f100,000\u3002</td></tr>'+
'<tr><td><strong>\u4e00\u822c\u5bc4\u4ed8\u91d1</strong></td><td class="r">\u8ab2\u7a0e\u6240\u5f97\u306e10%</td><td>\u627f\u8a8d\u3055\u308c\u305f\u6148\u5584\u56e3\u4f53\u3078\u306e\u5bc4\u4ed8\u3002</td></tr>'+
'<tr><td><strong>\u6559\u80b2\u30fb\u30b9\u30dd\u30fc\u30c4\u5bc4\u4ed8</strong></td><td class="r">2\u500d \u4e0a\u965010%</td><td>2\u500d\u63a7\u9664\u3002\u8ab2\u7a0e\u6240\u5f97\u306e10%\u307e\u3067\u3002</td></tr>'+
'</tbody></table>'+
'<div style="font-size:9px;color:var(--text3);margin-top:6px">\u6ce8\uff1aRMF + SSF + Thai ESG + PVD \u5408\u8a08\u4e0a\u9650\u0e3f500,000\u3002\u751f\u547d\u4fdd\u967a+\u5065\u5eb7\u4fdd\u967a \u5408\u8a08\u4e0a\u9650\u0e3f100,000\u3002\u91d1\u984d\u30fb\u6761\u4ef6\u306f\u6b73\u5165\u6cd5\u5178\u304a\u3088\u30732026\u5e74\u898f\u5247\u306b\u57fa\u3065\u304f\u3002\u7a0e\u52d9\u7f72\u307e\u305f\u306f\u7a0e\u7406\u58eb\u306b\u78ba\u8a8d\u3057\u3066\u304f\u3060\u3055\u3044\u3002</div>'
}
};


function getCardBreakdown(){
var breakdown={'Cash/Direct':{monthly:[],yearly:[],installments:[]}};
var nMo=0;if(SIM&&SIM.mAgg){nMo=Object.keys(SIM.mAgg).length}
if(!nMo)nMo=1;
D.cards.forEach(function(c){breakdown[c.name]={monthly:[],yearly:[],installments:[]}});
D.monthly.forEach(function(m){
var cn=m.card||'Cash/Direct';if(!breakdown[cn])breakdown[cn]={monthly:[],yearly:[],installments:[]};
breakdown[cn].monthly.push({name:m.name,amount:m.amount,annual:m.amount*nMo,direction:m.direction||'expense'})});
D.yearly.forEach(function(y){
var cn=y.card||'Cash/Direct';if(!breakdown[cn])breakdown[cn]={monthly:[],yearly:[],installments:[]};
breakdown[cn].yearly.push({name:y.name,amount:y.amount,pay_mode:y.pay_mode||'full',direction:y.direction||'expense'})});
allInstallments().filter(function(x){return x.status==='Active'||x.status==='Planned'}).forEach(function(inst){
var cn=inst.card||'Cash/Direct';if(!breakdown[cn])breakdown[cn]={monthly:[],yearly:[],installments:[]};
breakdown[cn].installments.push({name:inst.name,per_period:inst.per_period,periods:inst.periods,total:inst.total})});
return breakdown}
