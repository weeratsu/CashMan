// ui-dashboard.js — Dashboard & Analysis charts

function renderPeriodBanner(targetId,title){
var el=document.getElementById(targetId);if(!el||!D)return;
var sd=new Date(D.profile.start_date+'T00:00:00'),ed=new Date(D.profile.end_date+'T00:00:00');
var sStr=sd.getDate()+' '+MO[sd.getMonth()]+' '+sd.getFullYear();
var eStr=ed.getDate()+' '+MO[ed.getMonth()]+' '+ed.getFullYear();
var diffMs=ed-sd,diffDays=Math.round(diffMs/86400000);
var diffMo=Math.round(diffDays/30.44);
var spanTxt=diffDays+' days';
if(diffMo>=2)spanTxt=diffMo+' months ('+diffDays+' days)';
el.innerHTML='<div style="display:flex;align-items:center;gap:10px;padding:10px 14px;background:var(--primary-bg);border:1px solid var(--primary);border-radius:var(--radius);border-left:4px solid var(--primary)">'+
'<i class="fa-solid fa-calendar-days" style="font-size:16px;color:var(--primary)"></i>'+
'<div style="flex:1">'+
'<div style="font-size:13px;font-weight:700;color:var(--text)">'+(title||'Cash Flow Overview')+'</div>'+
'<div style="font-size:11px;color:var(--text2);margin-top:1px">'+
'<span style="font-weight:600">'+sStr+'</span>'+
' <i class="fa-solid fa-arrow-right" style="font-size:8px;color:var(--text3);margin:0 4px"></i> '+
'<span style="font-weight:600">'+eStr+'</span>'+
'<span style="color:var(--text3);margin-left:8px;font-size:10px">('+spanTxt+')</span></div></div></div>'}

function renderDash(){if(!SIM)return;var R=SIM;
renderPeriodBanner('dash-period','Dashboard');
document.getElementById('kpi-area').innerHTML=
'<div class="kpi"><div class="kpi-label">Starting</div><div class="kpi-val">฿'+fmt(D.profile.starting_cash)+'</div></div>'+
'<div class="kpi"><div class="kpi-label">Ending</div><div class="kpi-val text-success">฿'+fmt(R.finalB)+'</div></div>'+
'<div class="kpi"><div class="kpi-label">Income</div><div class="kpi-val text-success">฿'+fmt(R.totI)+'</div></div>'+
'<div class="kpi"><div class="kpi-label">Expenses</div><div class="kpi-val text-error">฿'+fmt(R.totE)+'</div></div>'+
'<div class="kpi"><div class="kpi-label">Lowest</div><div class="kpi-val text-warning">฿'+fmt(R.minB)+'</div><div class="kpi-note">'+MO[R.minDt.getMonth()]+' '+R.minDt.getDate()+'</div></div>'+
'<div class="kpi"><div class="kpi-label">Deficit Mo.</div><div class="kpi-val '+(R.def>0?'text-error':'text-success')+'">'+R.def+'</div></div>';
var dk=document.documentElement.classList.contains('dark'),tc=dk?'#e8eaed':'#1a1d27',tc2=dk?'#6b7185':'#7a8098',gc=dk?'#353849':'#d4d7e0',bg2=dk?'#1a1d27':'#fff',sc=dk?'#5b8def':'#4a7aed',ec=dk?'#f87171':'#dc2626',gc2=dk?'#4ade80':'#16a34a',wc=dk?'#fbbf24':'#d97706';
Highcharts.chart('chart-balance',{chart:{type:'areaspline',backgroundColor:'transparent',zooming:{type:'x'}},title:{text:'Daily Cash Balance',style:{color:tc,fontWeight:'600',fontSize:'13px'}},
xAxis:{type:'datetime',labels:{style:{color:tc2,fontSize:'9px'}},lineColor:gc},
yAxis:{title:{text:null},labels:{style:{color:tc2,fontSize:'9px'},formatter:function(){return Highcharts.numberFormat(this.value/1000,0)+'K'}},gridLineColor:gc,plotLines:[{color:wc,width:1,value:15000,dashStyle:'ShortDot'}]},
tooltip:{backgroundColor:bg2,borderColor:gc,style:{color:tc,fontSize:'10px'},xDateFormat:'%A, %b %e, %Y',pointFormat:'฿{point.y:,.2f}'},
series:[{name:'Balance',data:R.cData,color:sc,fillColor:{linearGradient:{x1:0,y1:0,x2:0,y2:1},stops:[[0,sc+'40'],[1,sc+'05']]},lineWidth:2,marker:{enabled:false,states:{hover:{enabled:true,radius:3}}}}],legend:{enabled:false},credits:{enabled:false}});
var mK=Object.keys(R.mAgg).sort(),mL=mK.map(function(k){var a=R.mAgg[k];return MO[a.m]+' '+String(a.y).slice(2)});
Highcharts.chart('chart-monthly',{chart:{type:'column',backgroundColor:'transparent'},title:{text:'Monthly Income vs Expenses',style:{color:tc,fontWeight:'600',fontSize:'13px'}},
xAxis:{categories:mL,labels:{style:{color:tc2,fontSize:'9px'}},lineColor:gc},
yAxis:{title:{text:null},labels:{style:{color:tc2,fontSize:'9px'},formatter:function(){return Highcharts.numberFormat(this.value/1000,0)+'K'}},gridLineColor:gc},
tooltip:{shared:true,backgroundColor:bg2,borderColor:gc,style:{color:tc,fontSize:'10px'},valuePrefix:'฿',valueDecimals:2},
plotOptions:{column:{borderRadius:3,borderWidth:0,groupPadding:.15}},
series:[{name:'Income',data:mK.map(function(k){return Math.round(R.mAgg[k].income*100)/100}),color:gc2},{name:'Expenses',data:mK.map(function(k){return Math.round(R.mAgg[k].expense*100)/100}),color:ec}],
legend:{itemStyle:{color:tc2,fontSize:'10px'}},credits:{enabled:false}});
// Gantt chart
var ganttData=[],cats=[];
R.allInst.filter(function(x){return x.status==='Active'||x.status==='Planned'}).forEach(function(inst,idx){
cats.push(inst.name);var sm=inst.start_month-1,sy=inst.start_year;var em=sm+inst.periods-1,ey=sy;
while(em>11){em-=12;ey++}var dl=cPD(inst.card)||15;
ganttData.push({x:Date.UTC(sy,sm,1),x2:Date.UTC(ey,em,Math.min(dl,dim(ey,em))),y:idx,color:COLORS[idx%COLORS.length]})});
var gh=Math.max(200,cats.length*28+60);
document.getElementById('chart-gantt').style.height=gh+'px';
Highcharts.chart('chart-gantt',{chart:{type:'xrange',backgroundColor:'transparent'},title:{text:null},
xAxis:{type:'datetime',labels:{style:{color:tc2,fontSize:'9px'}},lineColor:gc,gridLineWidth:1,gridLineColor:gc,
plotLines:[{color:ec,width:2,value:Date.UTC(2026,8,15),dashStyle:'Dash',label:{text:'Today',style:{color:ec,fontSize:'9px'}}}]},
yAxis:{categories:cats,reversed:true,labels:{style:{color:tc2,fontSize:'9px'}},gridLineColor:gc,title:{text:null}},
tooltip:{backgroundColor:bg2,borderColor:gc,style:{color:tc,fontSize:'10px'},
pointFormatter:function(){return '<b>'+this.yCategory+'</b><br/>'+Highcharts.dateFormat('%b %Y',this.x)+' \u2192 '+Highcharts.dateFormat('%b %Y',this.x2)}},
series:[{name:'Installments',data:ganttData,borderRadius:3,pointWidth:16,borderWidth:0,dataLabels:{enabled:false}}],legend:{enabled:false},credits:{enabled:false}})}

// === ANALYSIS ===

function renderAnalysis(){if(!SIM)return;var R=SIM;
renderPeriodBanner('analysis-period','Expense Analysis');
var dk=document.documentElement.classList.contains('dark'),tc=dk?'#e8eaed':'#1a1d27',tc2=dk?'#6b7185':'#7a8098',gc=dk?'#353849':'#d4d7e0',bg2=dk?'#1a1d27':'#fff';
// Pie
var pieData=Object.keys(R.typeExp).sort().map(function(t,i){return{name:t,y:Math.round(R.typeExp[t]*100)/100,color:COLORS[i%COLORS.length]}}).filter(function(d){return d.y>0});
Highcharts.chart('chart-pie',{chart:{type:'pie',backgroundColor:'transparent'},title:{text:null},
tooltip:{backgroundColor:bg2,borderColor:gc,style:{color:tc,fontSize:'10px'},pointFormat:'<b>฿{point.y:,.2f}</b> ({point.percentage:.1f}%)'},
plotOptions:{pie:{allowPointSelect:true,cursor:'pointer',borderWidth:0,innerSize:'45%',
dataLabels:{enabled:true,format:'{point.name}: {point.percentage:.1f}%',style:{color:tc2,fontSize:'10px',textOutline:'none'}}}},
series:[{name:'Expenses',data:pieData}],credits:{enabled:false}});
// Stacked bar by type per month
var mK=Object.keys(R.mAgg).sort(),mL=mK.map(function(k){var a=R.mAgg[k];return MO[a.m]+' '+String(a.y).slice(2)});
var allTypes=Object.keys(R.typeExp).sort();
var series=allTypes.map(function(t,ti){return{name:t,data:mK.map(function(k){return Math.round((R.mAgg[k].byType[t]||0)*100)/100}),color:COLORS[ti%COLORS.length]}});
Highcharts.chart('chart-type-bar',{chart:{type:'column',backgroundColor:'transparent'},title:{text:null},
xAxis:{categories:mL,labels:{style:{color:tc2,fontSize:'9px'}},lineColor:gc},
yAxis:{title:{text:null},labels:{style:{color:tc2,fontSize:'9px'},formatter:function(){return Highcharts.numberFormat(this.value/1000,0)+'K'}},gridLineColor:gc,stackLabels:{enabled:false}},
tooltip:{shared:true,backgroundColor:bg2,borderColor:gc,style:{color:tc,fontSize:'10px'},valuePrefix:'฿',valueDecimals:2},
plotOptions:{column:{stacking:'normal',borderRadius:2,borderWidth:0}},series:series,
legend:{itemStyle:{color:tc2,fontSize:'10px'}},credits:{enabled:false}});
// Summary table
var nMo=mK.length||1;
document.getElementById('type-summary-body').innerHTML=(function(){
var typeItems={};
D.monthly.forEach(function(m){var t=m.type||'Other';if(!typeItems[t])typeItems[t]=[];
typeItems[t].push({name:m.name,freq:'Monthly',amount:m.amount,annual:m.amount*12,card:m.card||'',direction:m.direction||'expense'})});
D.yearly.forEach(function(y){var t=y.type||'Other';if(!typeItems[t])typeItems[t]=[];
typeItems[t].push({name:y.name,freq:'Yearly',amount:y.amount,annual:y.amount,card:y.card||'',direction:y.direction||'expense'})});
allInstallments().filter(function(x){return x.status==='Active'||x.status==='Planned'}).forEach(function(x){
var t=x.type||'Other';if(!typeItems[t])typeItems[t]=[];
typeItems[t].push({name:x.name,freq:'Installment',amount:x.per_period,annual:x.per_period*12,card:x.card||'',direction:'expense'})});
return pieData.sort(function(a,b){return b.y-a.y}).map(function(d,di){
var pct=(d.y/R.totE*100).toFixed(1);
var items=(typeItems[d.name]||[]).sort(function(a,b){return b.annual-a.annual});
var detail='';
if(items.length>0){
detail='<tr id="type-detail-'+di+'" style="display:none"><td colspan="4" style="padding:0;background:var(--bg2)"><div style="padding:6px 12px">';
items.forEach(function(it){
var dirBadge=it.direction==='income'?'<span style="font-size:8px;padding:1px 4px;border-radius:6px;background:var(--success);color:#fff;margin-right:4px">Income</span>':'';
detail+='<div style="display:flex;align-items:center;gap:6px;padding:2px 0;font-size:10px">'+dirBadge+
'<span style="flex:1">'+esc(it.name)+'</span>'+
'<span style="font-size:9px;color:var(--text3);min-width:55px">'+it.freq+'</span>'+
(it.card?'<span style="font-size:9px;color:var(--text3);min-width:65px">'+esc(it.card)+'</span>':'')+
'<span style="font-family:var(--mono);font-size:10px;min-width:70px;text-align:right">\u0e3f'+fmt(it.amount)+(it.freq==='Monthly'?'/mo':it.freq==='Yearly'?'/yr':'/mo')+'</span></div>'});
detail+='</div></td></tr>'}
return '<tr style="cursor:pointer" onclick="var d=document.getElementById(\'type-detail-'+di+'\');if(d)d.style.display=d.style.display===\'none\'?\'\':\'none\'"><td>\u25b6 '+esc(d.name)+' <span style="font-size:9px;color:var(--text3)">('+items.length+')</span></td><td class="r" style="font-family:var(--mono);font-size:10px">\u0e3f'+fmt(d.y)+'</td><td class="r" style="font-family:var(--mono);font-size:10px">'+pct+'%</td><td class="r" style="font-family:var(--mono);font-size:10px">\u0e3f'+fmt(d.y/nMo)+'</td></tr>'+detail}).join('')+
'<tr style="font-weight:700;background:var(--bg3)"><td>TOTAL</td><td class="r" style="font-family:var(--mono);font-size:10px">\u0e3f'+fmt(R.totE)+'</td><td class="r">100%</td><td class="r" style="font-family:var(--mono);font-size:10px">\u0e3f'+fmt(R.totE/nMo)+'</td></tr>'})()
renderCardAn()}


function swAn(el,tab){
el.parentElement.querySelectorAll('.sub-tab').forEach(function(t){t.classList.remove('active')});el.classList.add('active');
document.querySelectorAll('#tab-analysis .sub-panel').forEach(function(p){p.classList.remove('active')});
document.getElementById('an-'+tab).classList.add('active');
if(tab==='card'){renderCardAn()}else{renderAnalysis()}}



function renderCardAn(){if(!SIM)return;var R=SIM;
var dk=document.documentElement.classList.contains('dark'),tc=dk?'#e8eaed':'#1a1d27',tc2=dk?'#6b7185':'#7a8098',gc=dk?'#353849':'#d4d7e0',bg2=dk?'#1a1d27':'#fff';
var cD=Object.keys(R.cardExp).sort().map(function(c,i){return{name:c,y:Math.round(R.cardExp[c]*100)/100,color:COLORS[i%COLORS.length]}}).filter(function(d){return d.y>0});
Highcharts.chart('chart-card-pie',{chart:{type:'pie',backgroundColor:'transparent'},title:{text:null},
tooltip:{backgroundColor:bg2,borderColor:gc,style:{color:tc,fontSize:'10px'},pointFormat:'<b>{point.y:,.2f}</b> ({point.percentage:.1f}%)'},
plotOptions:{pie:{allowPointSelect:true,cursor:'pointer',borderWidth:0,innerSize:'45%',
dataLabels:{enabled:true,format:'{point.name}: {point.percentage:.1f}%',style:{color:tc2,fontSize:'9px',textOutline:'none'}}}},
series:[{name:'By Card',data:cD}],credits:{enabled:false}});
var mK=Object.keys(R.mAgg).sort(),mL=mK.map(function(k){var a=R.mAgg[k];return MO[a.m]+' '+String(a.y).slice(2)});
var allC=Object.keys(R.cardExp).sort();
var cS=allC.map(function(c,ci){return{name:c,data:mK.map(function(k){return Math.round((R.mAgg[k].byCard[c]||0)*100)/100}),color:COLORS[ci%COLORS.length]}});
Highcharts.chart('chart-card-bar',{chart:{type:'column',backgroundColor:'transparent'},title:{text:null},
xAxis:{categories:mL,labels:{style:{color:tc2,fontSize:'9px'}},lineColor:gc},
yAxis:{title:{text:null},labels:{style:{color:tc2,fontSize:'9px'},formatter:function(){return Highcharts.numberFormat(this.value/1000,0)+'K'}},gridLineColor:gc},
tooltip:{shared:true,backgroundColor:bg2,borderColor:gc,style:{color:tc,fontSize:'10px'},valuePrefix:'฿',valueDecimals:2},
plotOptions:{column:{stacking:'normal',borderRadius:2,borderWidth:0}},series:cS,
legend:{itemStyle:{color:tc2,fontSize:'9px'}},credits:{enabled:false}});
var nMo=mK.length||1;var bd=getCardBreakdown();
var el3=document.getElementById('card-summary-body');if(el3){var rows='';
cD.sort(function(a,b){return b.y-a.y}).forEach(function(d){
var pct=(d.y/R.totE*100).toFixed(1);
rows+='<tr style="cursor:pointer" onclick="togInstMonth(this)">';
rows+='<td><span class="arr" style="font-size:8px;color:var(--text3)">\u25b6</span> '+esc(d.name)+'</td>';
rows+='<td class="r" style="font-family:var(--mono);font-size:10px">\u0e3f'+fmt(d.y)+'</td>';
rows+='<td class="r" style="font-family:var(--mono);font-size:10px">'+pct+'%</td>';
rows+='<td class="r" style="font-family:var(--mono);font-size:10px">\u0e3f'+fmt(d.y/nMo)+'</td></tr>';
rows+='<tr class="acc-body"><td colspan="4" style="padding:0"><div style="padding:4px 8px 4px 28px;background:var(--bg3)">';
var cb=bd[d.name]||{monthly:[],yearly:[],installments:[]};
if(cb.monthly.length){rows+='<div style="font-size:9px;font-weight:600;color:var(--text3);padding:4px 0 2px">MONTHLY RECURRING</div>';
cb.monthly.forEach(function(it){var cls=it.direction==='income'?'color:var(--success)':'';
rows+='<div style="display:flex;gap:6px;padding:1px 0;font-size:10px;'+cls+'"><span style="flex:1">'+esc(it.name)+'</span><span style="font-family:var(--mono);min-width:70px;text-align:right">\u0e3f'+fmt(it.amount)+'/mo</span></div>'})}
if(cb.yearly.length){rows+='<div style="font-size:9px;font-weight:600;color:var(--text3);padding:4px 0 2px">YEARLY RECURRING</div>';
cb.yearly.forEach(function(it){var cls=it.direction==='income'?'color:var(--success)':'';var badge=it.pay_mode==='installment'?'<span class="tag tag-auto" style="font-size:7px;margin-left:4px">Installment</span>':'';
rows+='<div style="display:flex;gap:6px;padding:1px 0;font-size:10px;'+cls+'"><span style="flex:1">'+esc(it.name)+badge+'</span><span style="font-family:var(--mono);min-width:70px;text-align:right">\u0e3f'+fmt(it.amount)+'</span></div>'})}
if(cb.installments.length){rows+='<div style="font-size:9px;font-weight:600;color:var(--text3);padding:4px 0 2px">INSTALLMENTS</div>';
cb.installments.forEach(function(it){
rows+='<div style="display:flex;gap:6px;padding:1px 0;font-size:10px"><span style="flex:1">'+esc(it.name)+'</span><span style="font-size:8px;padding:0 4px;border-radius:4px;background:var(--bg);color:var(--text3);font-family:var(--mono)">'+it.periods+' periods</span><span style="font-family:var(--mono);min-width:70px;text-align:right">\u0e3f'+fmt(it.per_period)+'/mo</span><span style="font-family:var(--mono);min-width:80px;text-align:right;color:var(--text2)">\u0e3f'+fmt(it.total)+' total</span></div>'})}
if(!cb.monthly.length&&!cb.yearly.length&&!cb.installments.length){rows+='<div style="font-size:10px;color:var(--text3);padding:4px">No items found</div>'}
rows+='</div></td></tr>'});
rows+='<tr style="font-weight:700;background:var(--bg3)"><td>TOTAL</td><td class="r" style="font-family:var(--mono);font-size:10px">\u0e3f'+fmt(R.totE)+'</td><td class="r">100%</td><td class="r" style="font-family:var(--mono);font-size:10px">\u0e3f'+fmt(R.totE/nMo)+'</td></tr>';
el3.innerHTML=rows}}

// === TIMELINE ===
