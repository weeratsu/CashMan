// TEST: First 100 lines of ui-payroll.js
// ui-payroll.js — Payroll Setup, Monthly Earnings, Tax Calculator, Tax Exemptions
function sortPayroll(col){
var st=sortState.payroll;if(st.col===col)st.asc=!st.asc;else{st.col=col;st.asc=true}
D.payroll.sort(function(a,b){if(a.type!==b.type)return a.type==='income'?-1:1;
var va=a[col],vb=b[col];if(typeof va==='number')return st.asc?va-vb:vb-va;
return st.asc?String(va||'').localeCompare(String(vb||'')):String(vb||'').localeCompare(String(va||''))});
renderPayroll()}

function renderPayroll(){
var incItems=[],dedItems=[];
D.payroll.forEach(function(p,i){p._gi=i;if(p.type==='income')incItems.push(p);else dedItems.push(p)});
var normalPay=computePayroll(1);var decPay=computePayroll(12);

function calcAmt(p,base){
if(p.calc_mode==='percent_epf'){return Math.round((base.epfBase)*(p.epf_pct||0)/100*100)/100}
if(p.calc_mode==='percent_sso'){var a=Math.round((base.ssoBase)*(p.sso_pct||5)/100*100)/100;if(p.sso_cap&&a>p.sso_cap)a=p.sso_cap;return a}
return p.amount}

function payRow(p){
var gi=p._gi;
var freqSel='<select class="sel" data-pi="'+gi+'" data-f="freq" onchange="readAll();renderPayroll()"><option value="every_month"'+(p.freq==='every_month'?' selected':'')+'>Every Month</option><option value="specific_month"'+(p.freq==='specific_month'?' selected':'')+'>Specific Month</option></select>';
var monthSel=p.freq==='specific_month'?'<select class="sel" data-pi="'+gi+'" data-f="month">'+MO.map(function(mn,mi){return '<option value="'+(mi+1)+'"'+(p.month===mi+1?' selected':'')+'>'+mn+'</option>'}).join('')+'</select>':'<span class="orig">All</span>';

var amtField;
if(p.calc_mode==='percent_epf'){var ca=calcAmt(p,normalPay);amtField='<span style="font-family:var(--mono);font-size:10px;color:var(--primary);font-weight:600">= ฿'+fmt(ca)+'</span>'}
else if(p.calc_mode==='percent_sso'){var ca2=calcAmt(p,normalPay);amtField='<span style="font-family:var(--mono);font-size:10px;color:var(--primary);font-weight:600">= ฿'+fmt(ca2)+'</span>'}
else{amtField='<input class="inp inp-num" type="text" value="'+fmt(p.amount)+'" style="width:75px;padding:2px 4px;font-size:10px" data-pi="'+gi+'" data-f="amount" onfocus="var v=parseFloat(this.value.replace(/,/g,\'\'));this.value=v||\'\';" onblur="this.value=(parseFloat(this.value.replace(/,/g,\'\'))||0).toLocaleString(\'en-US\',{minimumFractionDigits:2,maximumFractionDigits:2})">'}

var calcSel='<select class="sel" data-pi="'+gi+'" data-f="calc_mode" onchange="readAll();renderPayroll()"><option value="fixed"'+(p.calc_mode==='fixed'?' selected':'')+'>Fixed ฿</option>'+(p.type==='deduction'?'<option value="percent_epf"'+(p.calc_mode==='percent_epf'?' selected':'')+'>% of EPF Base</option><option value="percent_sso"'+(p.calc_mode==='percent_sso'?' selected':'')+'>% of SSO Base</option>':'')+'</select>';

var pctField='';
if(p.calc_mode==='percent_epf'){pctField='<input type="number" class="inp inp-num" value="'+(p.epf_pct||0)+'" min="0" max="100" step="0.5" style="width:45px;padding:2px 4px;font-size:10px" data-pi="'+gi+'" data-f="epf_pct">%'}
else if(p.calc_mode==='percent_sso'){pctField='<input type="number" class="inp inp-num" value="'+(p.sso_pct||5)+'" min="0" max="100" step="0.5" style="width:35px;padding:2px 4px;font-size:10px" data-pi="'+gi+'" data-f="sso_pct">% cap <input type="text" class="inp inp-num" value="'+fmt(p.sso_cap||750)+'" style="width:55px;padding:2px 4px;font-size:10px" data-pi="'+gi+'" data-f="sso_cap" onfocus="var v=parseFloat(this.value.replace(/,/g,\'\'));this.value=v||\'\';" onblur="this.value=(parseFloat(this.value.replace(/,/g,\'\'))||0).toLocaleString(\'en-US\',{minimumFractionDigits:2,maximumFractionDigits:2})">'}

var chkE='<input type="checkbox" data-pi="'+gi+'" data-f="affects_epf" '+(p.affects_epf?'checked':'')+' onchange="D.payroll['+gi+'].affects_epf=this.checked" style="margin:0">';
var chkS='<input type="checkbox" data-pi="'+gi+'" data-f="affects_sso" '+(p.affects_sso?'checked':'')+' onchange="D.payroll['+gi+'].affects_sso=this.checked" style="margin:0">';
var chkT='<input type="checkbox" data-pi="'+gi+'" data-f="affects_tax" '+(p.affects_tax?'checked':'')+' onchange="D.payroll['+gi+'].affects_tax=this.checked" style="margin:0">';

return '<tr><td><input class="inp-inline" value="'+esc(p.name)+'" data-pi="'+gi+'" data-f="name"></td>'+
'<td class="r">'+amtField+'</td>'+
'<td>'+calcSel+(pctField?' '+pctField:'')+'</td>'+
'<td>'+freqSel+'</td><td>'+monthSel+'</td>'+
'<td style="text-align:center">'+chkE+'</td><td style="text-align:center">'+chkS+'</td><td style="text-align:center">'+chkT+'</td>'+
'<td><button class="del-btn" onclick="readAll();D.payroll.splice('+gi+',1);renderPayroll()"><i class="fa-solid fa-trash"></i></button></td></tr>'}

document.getElementById('pay-income-body').innerHTML=incItems.map(payRow).join('');
document.getElementById('pay-deduct-body').innerHTML=dedItems.map(payRow).join('');

var normal=computePayroll(1);var bonus=computePayroll(12);
document.getElementById('payroll-kpis').innerHTML=
'<div class="kpi"><div class="kpi-label">Monthly Gross</div><div class="kpi-val text-success">฿'+fmt(normal.gross)+'</div></div>'+
'<div class="kpi"><div class="kpi-label">Monthly Deductions</div><div class="kpi-val text-error">฿'+fmt(normal.deduct)+'</div></div>'+
'<div class="kpi"><div class="kpi-label">Monthly Net Pay</div><div class="kpi-val text-primary">฿'+fmt(normal.net)+'</div></div>'+
'<div class="kpi"><div class="kpi-label">EPF Base</div><div class="kpi-val">฿'+fmt(normal.epfBase)+'</div></div>'+
'<div class="kpi"><div class="kpi-label">Dec Gross (+Bonus)</div><div class="kpi-val text-success">฿'+fmt(bonus.gross)+'</div></div>'+
'<div class="kpi"><div class="kpi-label">Dec Net Pay</div><div class="kpi-val text-primary">฿'+fmt(bonus.net)+'</div></div>';
var psTbl='<table class="tbl"><thead><tr><th>Component</th><th>Type</th><th>Freq</th><th class="r">Monthly</th><th class="r">Annual</th></tr></thead><tbody>';
D.payroll.forEach(function(p){
var isInc=p.type==='income';var mAmt=0,aAmt=0;
if(p.calc_mode==='percent_epf'){mAmt=Math.round(normalPay.epfBase*(p.epf_pct||0)/100*100)/100}
else if(p.calc_mode==='percent_sso'){mAmt=Math.round(normalPay.ssoBase*(p.sso_pct||5)/100*100)/100;if(p.sso_cap&&mAmt>p.sso_cap)mAmt=p.sso_cap}
else{mAmt=p.amount}
if(p.freq==='every_month'){aAmt=mAmt*12}else{aAmt=mAmt;mAmt=Math.round(mAmt/12*100)/100}
var sign=isInc?'+':'-';var col=isInc?'var(--success)':'var(--error)';
psTbl+='<tr><td>'+esc(p.name)+'</td><td style="font-size:9px;color:var(--text3)">'+(isInc?'Income':'Deduction')+'</td><td style="font-size:9px;color:var(--text3)">'+(p.freq==='every_month'?'Monthly':MO[(p.month||1)-1])+'</td><td class="r" style="font-family:var(--mono);font-size:10px;color:'+col+'">'+sign+'฿'+fmt(mAmt)+'</td><td class="r" style="font-family:var(--mono);font-size:10px;color:'+col+'">'+sign+'฿'+fmt(aAmt)+'</td></tr>'});
var annualNet=normal.net*12+(bonus.net-normal.net);
psTbl+='<tr style="font-weight:700;background:var(--bg3)"><td colspan="3">NET PAY</td><td class="r" style="font-family:var(--mono);font-size:10px;color:var(--primary)">฿'+fmt(normal.net)+'</td><td class="r" style="font-family:var(--mono);font-size:10px;color:var(--primary)">฿'+fmt(annualNet)+'</td></tr></tbody></table>';
document.getElementById('payroll-summary-tbl').innerHTML=psTbl}


function addPayItem(type){readAll();D.payroll.push({name:'New '+(type==='income'?'Income':'Deduction'),type:type,amount:0,freq:'every_month',month:null,notes:'',affects_epf:(type==='income'),affects_sso:(type==='income'),affects_tax:(type==='income'),calc_mode:'fixed'});renderPayroll()}


// TAX_BRACKETS defined in simulation.js


function swPayTax(el,tab){document.querySelectorAll('#tab-paytax .sub-panel').forEach(function(p){p.classList.remove('active')});document.querySelectorAll('#tab-paytax .sub-tab').forEach(function(t){t.classList.remove('active')});el.classList.add('active');document.getElementById('pt-'+tab).classList.add('active');
if(tab==='tax-calc')try{renderTax()}catch(e){};if(tab==='tax-exempt')try{renderExemptions()}catch(e){};if(tab==='monthly-earn')try{renderMonthlyEarnings()}catch(e){}}


function swTax(el,tab){
el.parentElement.querySelectorAll('.sub-tab').forEach(function(t){t.classList.remove('active')});el.classList.add('active');
document.querySelectorAll('#tab-paytax .sub-panel').forEach(function(p){p.classList.remove('active')});
document.getElementById('tax-'+tab).classList.add('active');renderTax()}



function applyTaxOverride(){
var el=document.getElementById('tax-override-input');
if(!el)return;
var v=el.value;
D.tax_actual_override=v?pn(v):null;
sS(SKEY,JSON.stringify(D));
location.hash='tax';location.reload()}

function resetTaxOverride(){
D.tax_actual_override=null;
sS(SKEY,JSON.stringify(D));
location.hash='tax';location.reload()}

