// app.js — Navigation, initialization, renderAllTabs

// NAV
document.getElementById('nav-tabs').onclick=function(e){var b=e.target.closest('.nav-tab');if(!b)return;
document.querySelectorAll('.tab-content').forEach(function(t){t.classList.remove('active')});
document.querySelectorAll('.nav-tab').forEach(function(t){t.classList.remove('active')});
b.classList.add('active');document.getElementById('tab-'+b.dataset.tab).classList.add('active');
if(b.dataset.tab==='dashboard')renderDash();if(b.dataset.tab==='analysis'){var at=document.querySelector('#tab-analysis .sub-tab.active');if(at&&at.textContent.indexOf('Card')>=0)renderCardAn();else renderAnalysis()};if(b.dataset.tab==='timeline')renderTimeline();if(b.dataset.tab==='paytax'){renderPayroll();try{renderTax()}catch(e){}};if(b.dataset.tab==='retirement'){try{renderRetirement()}catch(e){console.error('renderRetirement:',e)}};if(b.dataset.tab==='assets'){try{renderAssetsPage()}catch(e){console.error('renderAssetsPage:',e)}};if(b.dataset.tab==='help')renderHelp()};

function renderAllTabs(){renderCards();renderCardDetail();renderMonthly();renderYearly();renderPlanned();renderInst();renderInstMonthly();try{renderInstMatrix()}catch(e){};renderPayroll();renderRecurringSummary();populateFilters();try{renderRetirement()}catch(e){};try{renderAssetsPage()}catch(e){};if(typeof Highcharts!=='undefined')renderDash();try{renderTax()}catch(e){console.error('renderTax error:',e);var te=document.getElementById('tax-kpis');if(te)te.innerHTML='<div style="color:red;padding:10px">Error: '+e.message+''};try{filterMonthly();filterYearly();filterPlanned();filterInst()}catch(e){}
// Update data footer
var ft=document.getElementById('data-footer');
if(ft&&D){var lm=D.last_modified?new Date(D.last_modified):null;var ls=D.profile.name?'Profile: '+D.profile.name+' \u2022 ':'';ft.innerHTML='<i class="fa-solid fa-clock" style="margin-right:3px"></i>'+ls+(lm?'Last modified: '+lm.toLocaleDateString('en-GB')+' '+lm.toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit'}):'Not yet saved')+' \u2022 Data stored in browser localStorage (key: '+SKEY+')'}}

// INIT
try{loadTheme()}catch(e){console.error('loadTheme:',e)}
try{document.getElementById('theme-toggle').onclick=togTheme}catch(e){}
try{loadD();DATA_READY=true}catch(e){console.error('loadD:',e)}
try{loadForm()}catch(e){console.error('loadForm:',e)}
try{simulate()}catch(e){console.error('simulate:',e)}
try{renderAllTabs()}catch(e){console.error('renderAllTabs:',e)}
try{renderHelp()}catch(e){console.error('renderHelp:',e)}

if(location.hash){var ht=location.hash.slice(1);
var tabMap={'tax':'paytax','payroll':'paytax','recurring':'bills','installments':'bills','planned':'bills','cards':'setup'};
var actualTab=tabMap[ht]||ht;
var hb=document.querySelector('.nav-tab[data-tab="'+actualTab+'"]');
if(hb){document.querySelectorAll('.tab-content').forEach(function(t){t.classList.remove('active')});
document.querySelectorAll('.nav-tab').forEach(function(t){t.classList.remove('active')});
hb.classList.add('active');document.getElementById('tab-'+actualTab).classList.add('active');
if(ht==='tax'){document.querySelectorAll('#tab-paytax .sub-tab').forEach(function(t,i){t.classList.remove('active');if(i===2)t.classList.add('active')});document.querySelectorAll('#tab-paytax .sub-panel').forEach(function(p){p.classList.remove('active')});var tce=document.getElementById('pt-tax-calc');if(tce)tce.classList.add('active');try{renderTax()}catch(e){}}}}
